use db_mrsql
  go
  declare cur_employee cursor for
  select * from tb_employee13
  go

  
  
  use db_mrsql
  go
  declare mycursor cursor for		/*声明游标*/
  select 编号,姓名,性别 from tb_employee13
  open mycursor			/*打开游标*/
  go

  
  use db_mrsql
 go
  declare cursor_emp cursor for		  /*声明游标*/
   select 编号,姓名,性别,所属部门,入司时间 from tb_employee13
   where 入司时间 >'2013-01-01' 	/*定义游标结果集*/
  open cursor_emp             	/*打开游标*/ 
  fetch next from cursor_emp   		/*执行取数操作*/
while @@fetch_status = 0      	  /*判断是否还可以继续取数*/
   begin
     fetch next from cursor_emp
   end
     close cursor_emp           	/*关闭游标*/
     deallocate cursor_emp      		/*释放游标*/   

	 
	 
	 use db_mrsql
  go
  select 商品编号,商品名称 from tb_ware14
  where 数量 > 30
  go
  /*定义游标*/
   declare cur_ware scroll cursor for
    select 商品编号,商品名称 from tb_ware14
    where 数量 > 30
  open cur_ware			/*打开游标*/
    fetch last from cur_ware	/*读取游标最后一行*/
    fetch prior from cur_ware	/*读取游标中紧邻当前行前面的一行*/      
  close cur_ware			/*关闭游标*/
  deallocate cur_ware		/*释放游标*/

  
  
  use db_mrsql
  go
  declare @name varchar(10)			/*声明变量*/
  declare cur_lab cursor for			/*声明游标*/
    select 姓名 from tb_laborage13 where 编号 =1 /*定义游标结果集*/
  open cur_lab						/*打开游标*/
    fetch next from cur_lab into @name	/*将变量赋值*/
    while ( @@fetch_status=0 )  
begin
    declare @day varchar(10)			/*声明变量*/
    declare cur_lab_2 cursor for			/*声明游标*/
    select 请假天数 from tb_job13 where 姓名 = @name	/*定义结果集*/
    open cur_lab_2					/*打开游标*/
    fetch next from cur_lab_2 into @day	/*使用游标将变量赋值*/
    while ( @@fetch_status=0)  
    begin
          print '编号为1的员工的请假天数为' +@day +'天' 	/*输出编号为1的请假天数*/
          return 
    end
    close cur_lab_2					/*关闭游标*/
    deallocate cur_lab_2				/*释放游标*/ 
end   
    close cur_lab 
    deallocate cur_lab

	
	
	use db_mrsql
 go
 declare emp_cur cursor  		/*声明游标*/
 for
  select * from tb_emp13  	/*定义游标结果集*/ 
 open emp_cur           	/*打开游标*/
  fetch next from emp_cur  	/*执行取数操作*/
 while @@fetch_status = 0		/*判断是否可以继续取数*/
 begin
   fetch next from emp_cur
 end
 close emp_cur          	/*关闭游标*/
 deallocate emp_cur     		/*释放游标*/

 
 
 DECLARE @dept AS VARCHAR(20)							/*定义参数*/
SET @dept='Java开发部'									/*为参数赋值*/
DECLARE cur_eaf CURSOR								/*声明游标*/
  FOR (SELECT * FROM tb_eaf14 WHERE dept=@dept)		/*定义游标结果集*/
  OPEN cur_eaf										/*打开游标*/
    FETCH NEXT FROM cur_eaf							/*向下移动游标指针*/
    WHILE @@FETCH_STATUS = 0						/*判断是否存在下一条记录*/
      BEGIN
        FETCH NEXT FROM cur_eaf						/*向下移动游标指针*/
      END
  CLOSE cur_eaf										/*关闭游标*/
DEALLOCATE cur_eaf									/*释放游标*/




declare cursor dept_cursor(e_dept varchar2) is
select * from tb_emp
where department = e_dept;
r_department  tb_emp%rowtype;
  begin
     open dept_cursor('销售部');
  loop
     fetch dept_cursor into r_department;
  exit when  dept_cursor%notfound;
     dbms_output.put_line('编号: '||r_department.id ||' 姓名: '||r_department.name||
     ' 性别: '||r_department.sex ||' 所属部门: '||r_department.department);
   end loop;
  close dept_cursor;
end;



USE db_mrsql
DECLARE cur_eaf CURSOR					/*声明游标*/
  FOR (SELECT * FROM tb_eaf14)				/*定义游标结果集*/
  OPEN cur_eaf							/*打开游标*/
    PRINT CURSOR_STATUS('global','cur_eaf')	/*输出状态值*/
  CLOSE cur_eaf							/*关闭游标*/
DEALLOCATE cur_eaf						/*释放游标*/



USE db_mrsql
DECLARE cur_eaf SCROLL CURSOR
  FOR(SELECT * FROM tb_eaf14)
  OPEN cur_eaf
    PRINT @@CURSOR_ROWS
  CLOSE cur_eaf
DEALLOCATE cur_eaf



DECLARE cur_eca CURSOR
  FOR(SELECT * FROM tb_eca14)
  OPEN cur_eca
    FETCH NEXT FROM cur_eca
    UPDATE tb_eca14 SET date=getdate() WHERE CURRENT OF cur_eca
  CLOSE cur_eca
DEALLOCATE cur_eca



use db_mrsql
  select * from tb_laborage13
  go
  declare update_lab cursor 
   for select * from tb_laborage13 where 编号 = '2'
   for update of 基本工资,奖金
  open update_lab
   fetch next from update_lab
   go
    update tb_laborage13 set 基本工资 = 1560 where current of update_lab
   go
   close update_lab
   deallocate update_lab
  go

  
  
  
  DECLARE cur_ecb CURSOR
  FOR(SELECT * FROM tb_ecb14)
  OPEN cur_ecb
    FETCH NEXT FROM cur_ecb
    DELETE FROM tb_ecb14 WHERE CURRENT OF cur_ecb
  CLOSE cur_ecb
DEALLOCATE cur_ecb



use db_mrsql
  go
  declare @name varchar(8)
  declare delecursor cursor
    for select 姓名 from tb_laborage13
        where 姓名 not in (select 姓名 from tb_employee13)
    open delecursor
  fetch next from delecursor into @name
  while @@fetch_status = 0
    begin
     delete tb_laborage13
     where current of delecursor
     print '删除的员工为' + @name 
     return 
   end
    close delecursor  
    deallocate delecursor

	
	use db_mrsql
 go
  declare cur_ware cursor
    for select 商品编号,商品名称,(单价-进价)*数量 as 商品利润
    from tb_ware14
  open cur_ware
  fetch next from cur_ware
  while @@fetch_status = 0
    begin 
      fetch next from cur_ware
    end
  close cur_ware                                                       
  deallocate cur_ware

  
  
  use db_mrsql
  go
  declare mycursor cursor
  for select a.编号,a.姓名,性别,所属部门,入司时间,基本工资,奖金
  from tb_employee13 a,tb_laborage13 b
  where a.编号 = b.编号
  order by a.编号 desc
    open mycursor 
    fetch next from mycursor
    while @@fetch_status = 0
      fetch next from mycursor  
  close mycursor
  deallocate mycursor

  
  
  USE db_mrsql
DECLARE cur_eca CURSOR SCROLL  	--定义游标名称
  FOR 
    SELECT * FROM tb_eca14  		--定义游标结果集
DECLARE @cur_eca CURSOR  		--定义游标变量名
  SET @cur_eca = cur_eca  			--将游标赋值给游标变量
OPEN @cur_eca  					--打开游标变量
FETCH NEXT FROM @cur_eca
WHILE(@@FETCH_STATUS = 0)
  BEGIN
    FETCH NEXT FROM @cur_eca
  END
CLOSE @cur_eca  					--关闭游标变量
DEALLOCATE cur_eca




use db_mrsql
 go
 create procedure emp_cursor		/*创建存储过程*/
 @d_name varchar(10),			/*定义变量*/
 @dept cursor varying output		/*声明游标变量*/
 as
   set @dept = cursor  for		/*将游标变量赋值*/
   select * from tb_emp13
   where 所属部门 = @d_name
 open @dept					/*打开游标*/

go
declare @mycursor cursor			/*定义游标变量，用于接受存储过程的输出参数*/
 exec emp_cursor '销售部',  @dept = @mycursor  output
 fetch next from @mycursor		/*定位到游标的第一行*/
 while (@@fetch_status = 0)		/*判断FETCH是否成功执行*/
  begin
    fetch next from @mycursor		/*游标向后移动一行*/
  end
 deallocate @mycursor			/*释放游标变量*/ 

 
 
 use db_mrsql
  go
  declare k_eaf cursor keyset for		/*创建游标*/
    select name,dept from tb_EAF14 
    where duty = '程序员'			/*定义游标结果集*/
  open k_eaf					/*打开游标*/
  declare @eaf cursor			/*创建游标变量*/
  exec sp_cursor_list @cursor_return = @eaf output,
       @cursor_scope = 2		/*获取游标特征*/
  fetch next from @eaf			/*游标指针下移一行*/
  while(@@fetch_status<>-1) 		/*判断FETCH语句是否执行成功*/
    begin
      fetch next from @eaf 
    end
    close @eaf					/*关闭游标变量*/
    deallocate @eaf				/*释放游标变量*/
    close k_eaf  				/*关闭游标*/
    deallocate k_eaf 			/*释放游标*/  

	
	
	use db_mrsql
go
declare k_stu cursor keyset for 			--创建游标
select * from tb_stu13
open k_stu 						--打开游标
declare @Report cursor 				--创建游标变量
--使用sp_describe_cursor过程查看游标的属性信息
exec sp_describe_cursor @cursor_return = @Report output,
        @cursor_source = N'global', @cursor_identity = N'k_stu'   
fetch next from @Report				--游标指针下移一行
while(@@FETCH_STATUS <> -1)		--如果FETCH语句执行成功
begin
    fetch next from @Report			--游标继续向下移动
end
close @Report						--关闭游标变量
deallocate @Report					--释放游标变量 
go
close k_stu						--关闭游标
deallocate k_stu						--释放游标
go   



use db_mrsql
go
declare cur_stu cursor keyset for			--创建游标
select 学号,姓名 from tb_stu13
open cur_stu						--打开游标
declare @Report cursor				--创建游标变量
--使用sp_describe_cursor_columns过程报告游标所使用的列
EXEC  sp_describe_cursor_columns
      @cursor_return = @Report OUTPUT,
      @cursor_source = N'global', @cursor_identity = N'cur_stu'
fetch next from @Report				--游标指针下移一行
while(@@FETCH_STATUS <> -1)		--如果FETCH语句执行成功
begin
    fetch next from @Report			--游标继续向下移动
end
close @Report						--关闭游标变量
deallocate @Report					--释放游标变量 
go
close cur_stu						--关闭游标 
deallocate cur_stu					--释放游标
go                                   



use db_mrsql
go
declare k_ware cursor keyset for				--创建游标
select 商品编号,商品名称 from tb_ware14
open k_ware							--打开游标
declare @Report cursor					--创建游标变量
--使用sp_describe_cursor_tables报告游标所引用的表                                
EXEC  sp_describe_cursor_tables                                        
      @cursor_return = @Report OUTPUT,
      @cursor_source = N'global', @cursor_identity = N'k_ware'
fetch next from @Report						--游标指针下移一行
while(@@FETCH_STATUS <> -1)				--如果FETCH语句执行成功
begin
    fetch next from @Report					--游标继续向下移动
end
close @Report								--关闭游标变量
deallocate @Report							--释放游标变量
go
close k_ware								--关闭游标 
deallocate k_ware							--释放游标
go



declare cursor cur_emp is
    select name,sex,department from tb_emp where id = &id;
    v_name tb_emp.name%type;
    v_sex  tb_emp.sex%type;
    v_department tb_emp.department%type;
      begin
        open cur_emp;
       loop
         fetch cur_emp into v_name,v_sex,v_department;
         exit when cur_emp%notfound;
         dbms_output.put_line('姓名: '||v_name||',性别: '||v_sex||
         ',所属部门: '||v_department);
       end loop;
       close cur_emp;
      end;

	  
	  
	  begin
  delete from tb_emp where department = '策划部' and name = '李丽';
if SQL%ROWCOUNT = 1 then
  insert into tb_emp(id,name,sex,department)
  values('5','李丽','女','宣传部');
end if;
end;
