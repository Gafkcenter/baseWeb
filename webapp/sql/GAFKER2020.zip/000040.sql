create database mrgwh	--使用create database 命令创建一个名称是“mrgwh”的数据库

create database mrdz
on 
(name=mrdat,
filename='D:\Program Files\Sql server2000安装好的\MSSQL\Data\mrdz.mdf',
size=10,
maxsize=100,
filegrowth=5)
log on
(name='mingrilog',
filename='D:\Program Files\Sql server2000安装好的\MSSQL\Data\mrdz.ldf',
size=8mb,
maxsize=50mb,
filegrowth=8mb )


create database mr
on
 primary(
   name=mrdat,
   filename='D:\Program Files\Sql server2000安装好的\MSSQL\Data\mr.mdf',
   size=5,
   maxsize=80,
   filegrowth=5),
filegroup mrgroup
(
   name=mingri,
   filename='D:\Program Files\Sql server2000安装好的\MSSQL\Data\mr.ndf',
   size=10,
   maxsize=80,
   filegrowth=5
)
log on
(name='mrlog',
filename='D:\Program Files\Sql server2000安装好的\MSSQL\Data\lovingmr.ldf',
size=6mb,
maxsize=30mb,
filegrowth=6mb )


alter database db_mrsql--使用alter database 命令修改数据库
  add  file(  --添加文件“happy”
       name=happy,
       filename='D:\Program Files\Sql server2000安装好的\MSSQL\Data\happy.ndf',
       size=2mb,
       maxsize=30mb,
       filegrowth=3mb
)

alter database db_mrsql--使用alter database 命令修改数据库
  add  file(  --添加文件“joy”
       name=joy,
       filename='D:\temp\joy.ndf',
       size=2mb,
       maxsize=30mb,
       filegrowth=3mb
)

alter database db_mrsql 
modify file(
       name=joy,
       size=40mb
   )



use db_mrsql
DBCC SHRINKDATABASE (mrgwh,10,NOTRUNCATE)



alter database db_mrsql
add filegroup happy


alter database db_mrsql
remove file happy


use db_mrsql
DBCC SHRINKFILE(joy,1,NOTRUNCATE)



