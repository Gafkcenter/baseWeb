use db_mrsql--使用db_mrsql数据库
create table ##car –-创建一个全局临时表“##car”
(
车辆编号 int,
车辆名称  varchar(20),
车辆数量  int
)


use db_mrsql   --使用db_mrsql数据库  
--通过系统存储过程sp_help来查看药品销售信息表“tb_sell03”中的信息
EXEC  sp_help 'tb_sell03' 


USE  db_mrsql --使用db_mrsql数据库
/*通过使用系统存储过程sp_spaceused来查看学生信息表“tb_student04”中的行数及表格所用的存储空间*/
EXEC sp_spaceused 'tb_student04'


USE  db_mrsql--使用db_mrsql数据库
--使用系统存储过程sp_depends来查看学生信息表“tb_student04”和其他表的相关性
EXEC sp_depends 'tb_student04'


USE  db_mrsql--使用db_mrsql数据库
/*给学生信息表“tb_student04”添加“学生性别”列*/
alter table tb_student04 
add  学生性别  char(2)


use db_mrsql
--创建数据表
create table tb_student04
(
  学生学号 varchar(10),
  学生姓名 varchar(20)
) 
alter table tb_student04
alter column 学生学号 varchar(20)


USE  db_mrsql --使用db_mrsql数据库
--在学生信息表“tb_student04”中，将“学生学号”字段设置为主键
alter table tb_student04 add primary key(学生学号)


use db_mrsql --使用db_mrsql数据库
--在房屋信息表“tb_home04”中，删除名称是“zhufang”的约束
alter  table  tb_home04
drop constraint zhufang 


use db_mrsql--使用db_mrsql数据库
--使用EXEC sp_rename关键字将“student”数据表名称改成“stu”
EXEC sp_rename 'student', 'stu'


use db_mrsql  --使用db_mrsql数据库 
--  将房屋信息表“tb_home04”中的“住房备注”列修改为“备注信息”    
EXEC sp_rename 'tb_home04.[住房备注]', '备注信息', 'COLUMN'


use db_mrsql      --使用db_mrsql数据库
--使用ALTER TABLE命令从现有的学生信息表“tb_student04”中，删除 “学生性别”列
alter table tb_student04
drop column 学生性别



use db_mrsql 
alter table tb_home04 
add constraint 住房编号 
check (住房编号 >=1000 and 住房编号<=9999) 


use db_mrsql--使用db_mrsql数据库
alter  table  tb_home04 
add  constraint zhufang
default '备注' for 住房备注



use db_mrsql
drop table tb_storage04


--使用db_mrsql数据库
use db_mrsql
/*“tb_storage04”、“tb_stunum04”、
“tb_booksell04”这三个数据表*/
drop table tb_storage04,tb_stunum04,tb_booksell04



