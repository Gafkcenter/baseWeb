use db_mrsql
select * from tb_individualInfo05 
select * from tb_individualInfo05 where 姓名 like'王%'



use db_mrsql
select * from tb_individualInfo05 
select * from tb_individualInfo05 where 姓名 like '王小_'



use db_mrsql
select * from tb_employee06
select * from tb_employee06 where 工号 like 'A001[0-9]2'


use db_mrsql
select * from tb_employee06
select * from tb_employee06 where 工号 like '[^A]%'



use db_mrsql
select * from tb_str05 
select * from tb_str05 where Ооич like '[s[a-z]]df' 
select * from tb_str05 where Ооич like '\[s[a-z]]df' escape '\'



use db_mrsql
select * from tb_studentInfo05
select * from tb_studentInfo05 where Name  in('苏小雨','刘小詹')


use db_mrsql
select * from tb_studentInfo05
select * from tb_studentInfo05 where Age in(13+1,15)


use db_mrsql
select * from tb_studentScore05
select * from tb_studentScore05 where 89 in(ChineseScore,MathSocre)


use db_mrsql
select * from tb_studentInfo05
select * from tb_studentInfo05 where Name not in('苏小雨','刘小詹')


use db_mrsql
select * from tb_employeePay08
select * from tb_employeePay08 where 编号 not in 
(select top 8 编号 from tb_employeePay08 )


use db_mrsql
select * from tb_employee06
select top 1 * from tb_employee06 order by newID() 
select top 1 * from tb_employee06 order by newID()


use db_mrsql
select * from tb_employee06
select 编号=(select count(姓名)from tb_employee06 as A 
where A.姓名<=B.姓名),工号,姓名,性别,职务,部门 from tb_employee06
 as B order by 1

 
 
 use db_mrsql
select * from tb_employee06
select 编号=identity(int,1,1),工号,姓名,性别,职务,部门
into #s1 from tb_employee06
go
select * from #s1
go
drop table #s1
go



use db_mrsql
select * from tb_student06
select 编号,姓名,性别,年龄 from(select row_number() over (order by 编号) 
n,编号,姓名,性别,年龄 from tb_student06 )x
where n%2=1



use db_mrsql
select * from tb_bookInfo06
select * from tb_bookInfo06 where 出版社 is null

 
