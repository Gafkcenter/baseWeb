USE db_mrsql
GO
/*查看创建的索引*/
IF EXISTS (SELECT name FROM sysindexes 
   WHERE name = 'StuName_Index')
/*删除索引*/
  DROP INDEX tb_Student16.StuName_Index
GO
CREATE INDEX StuName_Index 
ON tb_Student16(学生姓名)
SELECT 学生姓名 FROM tb_Student16
GO





USE db_mrsql
GO
/*强制使用非簇索引查询学生信息表中信息*/
SELECT * 
FROM tb_Student16
WITH (INDEX(StuName_Index))
GO




USE db_mrsql
GO
/*查看是否创建了MRName_Index索引*/
IF EXISTS(SELECT name from sysindexes
   WHERE name = 'MRName_Index')
/*删除名为MRName_Index的索引*/
   DROP INDEX tb_StudentInfo16.MRName_Index
GO
CREATE INDEX MRName_Index
    ON tb_StudentInfo16(性别,学生姓名)
GO
/*强制使用非簇索引查询tb_StudentInfo16表中信息*/
SELECT * FROM tb_StudentInfo16 
WITH (INDEX(MRName_Index)) 







USE db_mrsql
GO
/*查看是否创建了MRBooks_Index索引*/
IF EXISTS(SELECT name from sysindexes
   WHERE name = 'MRBooks_Index')
/*删除名为MRBooks_Index的索引*/
   DROP INDEX tb_mrBook16.MRBooks_Index
GO
/*创建唯一索引，且指定降序排列*/
CREATE UNIQUE INDEX MRBooks_Index
    ON tb_mrBook16(图书编号 DESC)
GO
/*强制使用MRBooks_Index索引，查询tb_mrBook16表中
所有记录*/
SELECT * FROM tb_mrBook16 
WITH (INDEX(MRBooks_Index))
GO







USE db_mrsql
GO
/*查看是否创建了Memmbers_Index索引*/
IF EXISTS(SELECT name from sysindexes
   WHERE name = 'Memmbers_Index')
/*删除名为MRBooks_Index的索引*/
   DROP INDEX tb_MRMemmbers16.Memmbers_Index
GO
/*创建簇索引，且指定降序排列*/
CREATE CLUSTERED INDEX Memmbers_Index
    ON tb_MRMemmbers16(员工编号 DESC)
GO
/*使用SELECT语句查询tb_MRMemmbers16表中
所有记录*/
SELECT * FROM tb_MRMemmbers16 
GO


USE db_mrsql
GO
/*查看是否创建了Emp_Index索引*/
IF EXISTS(SELECT name from sysindexes
   WHERE name = 'Emp_Index')
/*删除名为Emp_Index的索引*/
   DROP INDEX tb_mrEmployee16.Emp_Index
GO
/*创建多字段簇索引*/
CREATE CLUSTERED INDEX Emp_Index
    ON tb_mrEmployee16(性别,地址)
GO
/*使用SELECT语句查询tb_mrEmployee16表中所有记录*/
SELECT * FROM tb_mrEmployee16 
GO







/*创建员工信息表,并创建"本月应发工资"虚拟列*/
CREATE TABLE tb_mrEmp16(员工编号 int,当月工资 money,扣罚金额 money,本月应发工资 AS (当月工资-扣罚金额))
GO
/*创建索引列索引*/
CREATE INDEX Emp_Index ON tb_mrEmp16(本月应发工资)
GO





USE db_mrsql
GO
/*创建员工信息表,并创建表中"工龄"虚拟列*/
CREATE TABLE tb_fdwEmp16
(员工编号 int identity(1001,1),
雇佣日期 datetime,
工龄 AS DATEDIFF(YEAR,雇佣日期,GETDATE()))
GO
/*创建索引列索引*/
CREATE INDEX Emp_Index ON tb_fdwEmp16(工龄)
GO



create index score_index16
on tb_score16
(score1+score2)
/



USE db_mrsql
GO
/*变量声明*/
DECLARE @table_id int
SET @table_id = object_id('tb_mrBook15')
/*查看tb_mrBook15表的索引信息*/
DBCC SHOWCONTIG(@table_id)
GO



USE db_mrsql
GO
DBCC DBREINDEX('db_mrsql.dbo.tb_mrHY16',HY_Index, 80)
GO

USE db_mrsql
GO
DBCC DBREINDEX('db_mrsql.dbo.tb_mrHY16', '' , 100)
GO



DBCC INDEXDEFRAG(db_mrsql,tb_Student16,Stu_Index)
GO



USE db_mrsql
GO
/*查看是否创建了Mer_Index索引*/
IF EXISTS(SELECT name from sysindexes
   WHERE name = 'Mer_Index')
/*删除名为Mer_Index的索引*/
   DROP INDEX tb_mrMerchan16.Mer_Index
GO




