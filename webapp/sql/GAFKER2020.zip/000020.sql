
use db_mrsql     --使用db_mrsql数据库
declare  @x int  -- 使用DECLARE关键字声明一个变量@x
select @x=1001  -- 将数字1001赋给变量@x
print @x        -- 使用PRINT关键字将变量@x的值输出 

use db_mrsql  --使用db_mrsql数据库
backup DATABASE db_mrsql TO disk='backupsql.bak'

use db_mrsql  --使用db_mrsql数据库
--使用SELECT关键字查询商品信息表"tb_spreadtext03"
select 商品备注 from tb_spreadtext03
--使用DECLARE关键字声明一个变量
DECLARE @sp varbinary(20)
SELECT @sp= TEXTPTR(商品备注) 
   FROM tb_spreadtext03 
READTEXT tb_spreadtext03.商品备注 @sp  0  9  

use db_mrsql--使用db_mrsql数据库
--使用DECLARE关键字声明4个变量
declare @timesj1 varchar(30),@timesj2 varchar(30),
@timenow varchar(30)
/*使用SET关键字为变量@timesj1和变量@timesj2分别
赋值为"2008/02/18"和"2008/04/02"*/
set @timesj1='2008/02/18'
set @timesj2='2008/04/02'
--使用SET关键字将当前时间赋给变量@timenow
set @timenow=(CONVERT(varchar(30),GETDATE(),111))
--使用IF判断变量@timesj1是否等于变量@timenow
if @timesj1<>@timenow
/*如果两个变量不相等,使用PRINT关键字输出
"@timesj1和@timenow两个时间不相同！"*/
  print '@timesj1和@timenow两个时间不相同！'
else
/*如果两个变量相等,使用PRINT关键字输出
"@timesj1和@timenow两个时间相同！"*/
  print '@timesj1和@timenow两个时间相同！'
--使用IF判断变量@timesj2是否等于变量@timenow
if @timesj2<>@timenow
/*如果两个变量不相等,使用PRINT关键字输出
"@timesj1和@timenow两个时间不相同！"*/
  print '@timesj2和@timenow两个时间不相同！'
else
/*如果两个变量相等,使用PRINT关键字输出
"@timesj1和@timenow两个时间相同！"*/
  print '@timesj2和@timenow两个时间相同！'


use db_mrsql --使用db_mrsql数据库
--使用DECLARE关键字声明5个变量
declare @A varchar(10),@B varchar(10),@C varchar(10),
@D varchar(50),@E varchar(20) 
--使用SELECT关键字为这5个变量赋值                           
select @A='weihong',@B='女',@C='23',@D='吉林省长春市',
@E='weihong@XX.com'
--使用print关键字显示变量并生成字符串
print '注册信息:-)'
print '您的姓名：'+ @A
print '您的性别：'+ @B
print '您的年龄: '+ @C
print '家庭住址: '+ @D
print '邮箱：'+@E


use db_mrsql--使用db_mrsql数据库
/*使用CHECKPOINT命令检查db_mrsql数据库中被更改过的数据页或日志页，并将这些数据从数据缓冲器中强制写入硬盘*/
CHECKPOINT


use pubs  --使用pubs数据库
/*使用 OBJECT_ID 获得表 ID 和使用 sysindexes 获得索引 ID*/
DECLARE @id int, @indid int--使用DECLARE关键字声明两个变量
SET @id = OBJECT_ID('authors')--使用SET关键字为变量@id复值
SELECT @indid = indid 
FROM sysindexes
WHERE id = @id 
   AND name = 'aunmind'
--使用DBCC SHOWCONTIG命令显示指定的表的数据和索引的碎片信息
DBCC SHOWCONTIG (@id, @indid)


use db_mrsql  --使用db_mrsql数据库
--检查指定pubs数据库的磁盘空间分配结构的一致性
DBCC CHECKALLOC ('pubs')   


use db_mrsql--使用db_mrsql数据库
WAITFOR DELAY'00:00:08' --等待8分钟              
print'你好！！'--使用print关键字输出"你好！！"


use db_mrsql             --使用db_mrsql数据库
WAITFOR TIME '7:00:00'  --时间等到7点钟
PRINT '小赖虫起床了！'   --使用PRINT显示一句话"小赖虫起床了！"



use db_mrsql--使用db_mrsql数据库
--使用DECLARE关键字声明3个变量
declare  @x int,@y char(20),@z datetime
/*使用SELECT关键字为变量@x,@y,@z赋值,
分别赋值为"50","LOVING","2008/03/04" */                    
select @x=50,@y='LOVING',@z='2008/03/04'
print @x
print @y
print @z


use db_mrsql  --使用db_mrsql数据库
declare @stuname varchar(30)
declare @sex char(2)
declare @score float
declare @class varchar(20)
select @stuname=学生姓名,@score=学生成绩,@sex=学生性别,@class=所在班级
from tb_student03 where 学生编号=1001
print @stuname
print @sex
print @class
print @score  


use db_mrsql --使用db_mrsql数据库
declare @M varchar(10)  -- 使用DECLARE声明一个变量@M
set @M='你们好！！'     -- 使用SET关键字将变量@M赋值为"你们好！！"
print @M                -- 使用PRINT关键字输出变量@M的值


use db_mrsql --使用db_mrsql数据库
SHUTDOWN  
WITH NOWAIT


use master --使用MASTER数据库
GO

