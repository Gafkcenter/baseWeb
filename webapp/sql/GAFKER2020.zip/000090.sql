select *
FROM tb_Stu07
ORDER BY age DESC
SELECT *
FROM tb_Stu07
ORDER BY age ASC



SELECT id, name, sex, age AS 年龄, address, speciality, class
FROM tb_Stu07
ORDER BY 年龄 DESC



SELECT id, name, sex, age AS '年 龄', address, speciality, class
FROM tb_Stu07
ORDER BY '年 龄' DESC


SELECT id, name, sex, age AS 年龄, address, speciality, class, DATEADD(year, 
      - (age - 1), GETDATE()) AS 出生年月
FROM tb_Stu07
ORDER BY DATEADD(year, - (age - 1), GETDATE())


INSERT INTO tb_Stu07
      (id, name, sex, address, speciality, class)
VALUES ('xh04033332', '蒙蒙X', '女', '吉林', '英语', '04188')
SELECT *
FROM tb_Stu07


INSERT INTO tb_Stu07
      (id, name, sex, address, speciality, class)
VALUES ('xh04034432', '小花x', '女', '吉林', '计算机', '04088')
SELECT *
FROM tb_Stu07
ORDER BY age DESC



SELECT *
FROM tb_pro07
ORDER BY prod_price, prod_name



SELECT TOP 1 *
FROM tb_pro07
ORDER BY prod_price



select * from
(select prod_id,prod_price,prod_name 
from tb_pro07
order by prod_price desc) 
where rownum<=3;




select * from
(select * from tb_pro07 order by prod_price desc)
where rownum=1;




SELECT *
FROM tb_order07
ORDER BY RIGHT(xh, Len(xh)-1)



SELECT *
FROM tb_order07
ORDER BY YEAR(order_date) DESC, MONTH(order_date) DESC, DAY(order_date) DESC



SELECT *
FROM tb_test07
ORDER BY CAST(STUFF(xh, 1, 1, ' ') AS int) DESC



select t.* 
from tb_test07 t 
order by cast(substr(xh,2) as int)



SELECT *
FROM tb_lk07
WHERE (lh = 'A座')
ORDER BY CHARINDEX(LEFT(dy, 1), '一二三四五六七八九十') DESC



SELECT *
FROM tb_name07
ORDER BY LEFT(name, 1) COLLATE Chinese_PRC_Stroke_CS_AS_KS_WS DESC



SELECT TOP 3 *
FROM tb_pro07
ORDER BY prod_price DESC


SELECT *
FROM tb_name07
ORDER BY LEFT(name, 1) COLLATE Chinese_PRC_CS_AS_KS_WS DESC



SELECT *
FROM tb_Stu07
ORDER BY 4 DESC



SELECT *
FROM tb_pro07
ORDER BY 2, 3


SELECT name, job, salary, 
      CASE job WHEN '会计' THEN salary * 1.15 WHEN '秘书' THEN salary * 1.20 WHEN '程序员'
       THEN salary * 1.25 WHEN '经理' THEN salary * 1 END AS [new salary]
FROM tb_emp07
ORDER BY CASE job WHEN '会计' THEN salary * 1.15 WHEN '秘书' THEN salary * 1.20 WHEN
       '程序员' THEN salary * 1.25 WHEN '经理' THEN salary * 1 END

	   
	   
	   select name,job,salary,DECODE(job,'会计',salary*1.15,
'秘书',salary*1.20,
'程序员',salary*1.25,
'经理',salary*1) as "new salary"
from tb_emp07
order by "new salary";



SELECT *
FROM (SELECT TOP 3 *
        FROM tb_Stu07
        ORDER BY newid()) DERIVEDTBL
ORDER BY age



INSERT INTO tb_Stu07
      (id, name, sex, address, speciality, class)
VALUES ('xh04034432', '小花x', '女', '吉林', '计算机', '04088')
SELECT *
FROM tb_Stu07
ORDER BY age DESC



