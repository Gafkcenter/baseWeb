USE db_mrsql
GO
SELECT 库存编号,订单编号,
SUM(商品数量) OVER() AS 商品总数量,
COUNT(商品数量)OVER() AS 整个表的记录数,
AVG(商品数量)OVER() AS 平均值,
MIN(商品数量)OVER() AS 最小数量,
MAX(商品数量)OVER() AS 最大数量
FROM tb_sales09;



USE db_mrsql
GO
SELECT 订单编号, 商品编号, 订货数量
    ,SUM(订货数量) OVER(PARTITION BY 订单编号) AS '总计'
    ,AVG(订货数量) OVER(PARTITION BY 订单编号) AS '平均'
    ,COUNT(订货数量) OVER(PARTITION BY 订单编号) AS '计数'
    ,MIN(订货数量) OVER(PARTITION BY 订单编号) AS '最小'
    ,MAX(订货数量) OVER(PARTITION BY 订单编号) AS '最大'
FROM tb_MRSales09 
WHERE 订单编号 IN(1314,5257);
GO



SELECT EmployeeID,
 CAST(SUBSTRING(binstr,1,8) AS DATETIME) AS OrderDate,
 CAST(SUBSTRING(binstr,17,4) AS INT) AS OrderID,
 CAST(SUBSTRING(binstr,21,10) AS NCHAR(5)) AS CustomerID
FROM (SELECT EmployeeID,
 MAX(CAST(OrderDate AS BINARY(8))
     +CAST(OrderID AS BINARY(4))
     +CAST(CustomerID AS BINARY(10))
     ) AS binstr
FROM dbo.tb_Orders
GROUP BY EmployeeID) AS MRSOFT;


USE db_mrsql
GO  
SELECT MR.员工编号,CONVERT(VARCHAR(7),
 MR.订单月份,121)AS 订单月份,
 MR.订单数量 AS 当月数量,SUM(MRSOFT.订单数量)AS 订单总数,
CAST(AVG(1.*MRSOFT.订单数量)AS DECIMAL(12,2))AS 平均数量
FROM tb_EmpOrders09 AS MR
JOIN tb_EmpOrders09 AS MRSOFT
ON MRSOFT.员工编号=MR.员工编号 
AND MRSOFT.订单月份<=MR.订单月份
GROUP BY MR.员工编号,MR.订单月份,MR.订单数量
ORDER BY MR.员工编号,MR.订单月份;
GO



USE db_mrsql
GO
SELECT MR.员工编号,CONVERT(VARCHAR(7),MR.订单月份,121)
 AS 订单月份,
MR.订单数量 AS 当月数量,
(SELECT SUM(MRSOFT.订单数量)
FROM tb_EmpOrders09 AS MRSOFT
WHERE MR.员工编号=MRSOFT.员工编号
AND MRSOFT.订单月份<=MRSOFT.订单月份) AS 订单总数
FROM tb_EmpOrders09 AS MR
GROUP BY MR.员工编号,MR.订单月份,MR.订单数量;
GO



USE db_mrsql
GO  
SELECT MR.员工编号,CONVERT(VARCHAR(7),
 MR.订单月份,121)AS 订单月份,
 MR.订单数量 AS 当月数量,SUM(MRSOFT.订单数量)AS 订单总数,
CAST(AVG(1.*MRSOFT.订单数量)AS DECIMAL(12,2))AS 平均数量
FROM tb_EmpOrders09 AS MR
JOIN tb_EmpOrders09 AS MRSOFT
ON MRSOFT.员工编号=MR.员工编号
AND (MRSOFT.订单月份>DATEADD(month,-3,MR.订单月份)
AND MRSOFT.订单月份<=MR.订单月份)
GROUP BY MR.员工编号,MR.订单月份,MR.订单数量
ORDER BY MR.员工编号,MR.订单月份;
GO


USE db_mrsql
GO  
SELECT MR.员工编号,CONVERT(VARCHAR(7),
 MR.订单月份,121)AS 订单月份,
 MR.订单数量 AS 当月数量,SUM(MRSOFT.订单数量)AS 订单总数,
CAST(AVG(1.*MRSOFT.订单数量)AS DECIMAL(12,2))AS 平均数量
FROM tb_EmpOrders09 AS MR
JOIN tb_EmpOrders09 AS MRSOFT
ON MRSOFT.员工编号=MR.员工编号
AND (MRSOFT.订单月份>=CAST(CAST(YEAR(MR.订单月份)AS CHAR(4))
          +'0101' AS DATETIME)
AND MRSOFT.订单月份<=MR.订单月份)
GROUP BY MR.员工编号,MR.订单月份,MR.订单数量
ORDER BY MR.员工编号,MR.订单月份;
GO



use db_mrsql
select * from tb_Aeddy09			--显示原数据表
--对原数据表进行简单旋转
select max(case when 月份='一月份' then 个数 else 0 end) as '一月份',
     max(case when 月份='二月份' then 个数 else 0 end) as '二月份',
     max(case when 月份='三月份' then 个数 else 0 end) as '三月份',
     max(case when 月份='四月份' then 个数 else 0 end) as '四月份',
     max(case when 月份='五月份' then 个数 else 0 end) as '五月份',
     max(case when 月份='六月份' then 个数 else 0 end) as '六月份'  
from tb_Aeddy09



use db_mrsql
select * from tb_Aeddy09			--显示原数据表
--将数据表旋转成一行数据
select max(case when 月份='一月份' then 个数 else 0 end) as '一月份',
     max(case when 月份='二月份' then 个数 else 0 end) as '二月份',
     max(case when 月份='三月份' then 个数 else 0 end) as '三月份',
     max(case when 月份='四月份' then 个数 else 0 end) as '四月份',
     max(case when 月份='五月份' then 个数 else 0 end) as '五月份',
     max(case when 月份='六月份' then 个数 else 0 end) as '六月份' 
from tb_Aeddy09



use db_mrsql
select * from tb_distribution09			--显示原数据表
--对数据表进行旋转后求和
select sum(case when 月份='一月' then 销售个数 else 0 end) as '一月份',
     sum(case when 月份='二月' then 销售个数 else 0 end) as '二月份',
     sum(case when 月份='三月' then 销售个数 else 0 end) as '三月份',
     sum(case when 月份='四月' then 销售个数 else 0 end) as '四月份',
     sum(case when 月份='五月' then 销售个数 else 0 end) as '五月份',
     sum(case when 月份='六月' then 销售个数 else 0 end) as '六月份'
from tb_distribution09



use db_mrsql
declare @str varchar(8000)
set @str='年份,'
select @str=@str+''''+月份+''''+ '=sum(case 月份 when '+''''+月份+''''+' then 个数 else 0 end),' 
from tb_YearD09 group by 月份
set @str='select '+substring(@str,1,len(@str)-1)+',sum(个数) 总计 from tb_YearD09 group by 年份'
print(@str)	--显示@str变量中的SQL语句
exec( @str)	--执行@str变量中的SQL语句



use db_mrsql
select d.月份,
  case d.个数 
      when 一月份 then e.一月份
      when 二月份 then e.二月份
      when 三月份 then e.三月份
      when 四月份 then e.四月份
      when 五月份 then e.五月份
      when 六月份 then e.六月份
  end as 个数
from (
select max(case when 月份='一月份' then 个数 else 0 end) as '一月份',
          max(case when 月份='二月份' then 个数 else 0 end) as '二月份',
          max(case when 月份='三月份' then 个数 else 0 end) as '三月份',
          max(case when 月份='四月份' then 个数 else 0 end) as '四月份',
          max(case when 月份='五月份' then 个数 else 0 end) as '五月份',
          max(case when 月份='六月份' then 个数 else 0 end) as '六月份'  
from tb_Aeddy09) e,(select * from tb_Aeddy09) d


transform  sum(销量) as 总销量 select 语言类别 from 图书销售  group by 语言类别  pivot 销售时间


SELECT 员工姓名, SUM(CASE 所在部门 WHEN '食品部' THEN 销售业绩 ELSE NULL END) AS [食品部业绩],SUM(CASE 所在部门 WHEN '家电部' THEN 销售业绩 ELSE NULL END) AS [家电部业绩]FROM 销售 GROUP BY 员工姓名



USE db_mrsql
go
select * from tb_privot20	--显示原数据表
--用PIVOT语句实现交叉表
select 商品名称,a.[9] as [九月],a.[10] as [十月],a.[11] as [十一月],a.[12] as [十二月] 
from tb_privot20 
pivot(sum(销售数量) for 月份 
in ([9],[10],[11],[12]))as a
go



--用Sql Server 2005数据库
use db_mrsql
go
select * from tb_unpivot09	--显示自定义的旋转样式数据表
--实现数据表的反向交叉表
select 编号, 数字, Orders 
from 
   (select 编号, 数字1, 数字2, 数字3, 数字4, 数字5 
   from tb_unpivot09) p 
unpivot
   (Orders for 数字 in 
      (数字1, 数字2, 数字3, 数字4, 数字5)
)as unpvt
go



use db_mrsql
select * from tb_YearD09	--原数据表
select 年份,月份,个数 from tb_YearD09 order by 年份,月份	--为了便于观察，对数据表进行排序
--对数据表进行旋转后汇总重复字段
select 年份,  sum(case when 月份='1月' then 个数 else 0 end) as '一月份',
             sum(case when 月份='2月' then 个数 else 0 end) as '二月份',
            sum(case when 月份='3月' then 个数 else 0 end) as '三月份',
            sum(case when 月份='4月' then 个数 else 0 end) as '四月份',
            sum(case when 月份='5月' then 个数 else 0 end) as '五月份',
            sum(case when 月份='6月' then 个数 else 0 end) as '六月份'  
from tb_YearD09 group by 年份
