Use db_mrsql
Select 商品名称 From tb_commodity05



Use db_mrsql
Select 编号,商品名称,商品价格 From tb_commodity05



Use db_mrsql
Select * From tb_commodity05


Use db_mrsql
select ID as"编号",Name as "姓名",ChineseScore,
MathSocre,EnglishSocre from tb_studentScore05



use db_mrsql
select tb_studentScore05.ID as "成绩中的编号",
tb_studentInfo05.ID as "信息中的编号",tb_studentScore05.Name
from tb_studentScore05,tb_studentInfo05
where tb_studentInfo05.ID=tb_studentScore05.ID




use db_mrsql
select ID,Name,ChineseScore,MathSocre,EnglishSocre,
(ChineseScore+MathSocre+EnglishSocre) as "三科成绩总分数"
 from tb_studentScore05

 
 
 use db_mrsql
select sum(ChineseScore) as "全班语文成绩总分" ,
avg(chineseScore) as "全班语文成绩平均分" 
from tb_studentScore05


use db_mrsql
select * from tb_studentScore05
select top 2  * from tb_studentScore05



use db_mrsql
select * from tb_studentScore05
select top 60 percent * from tb_studentScore05



use db_mrsql
select * from tb_studentScore05
select top 3 * from tb_studentScore05 order by ID  desc



use db_mrsql
select Name+sex as "学生信息" from tb_studentInfo05



use db_mrsql
select 编号,商品名称,单价-进价 as 销售利润 from tb_goods05


use db_mrsql
select 编号,商品名称,销售数量*单价 as 销售额 from tb_goods05


use db_mrsql
select 编号,商品名称, (销售数量*单价-进价*销售数量)/销售数量
as 销售利润 from tb_goods05


use db_mrsql
select 编号,商品名称,销售数量,进价+50 as 进价,单价 from tb_goods05


use db_mrsql
select 编号,商品名称,convert(char(2),销售数量)+'台' as 销售数量 ,
convert(char(8),进价)+'元' as 进价 from tb_goods05



use db_mrsql
select 编号,商品名称,1+1,'字符'+'串列'from tb_goods05




use db_mrsql
select * from tb_goods05 where 编号=003



use db_mrsql
select * from tb_goods05 where 销售数量>35


use db_mrsql
select * from tb_goods05 where 销售数量<35


use db_mrsql
select * from tb_goods05 where 销售数量>=35



use db_mrsql
select * from tb_goods05 where 销售数量<=35



use db_mrsql
select * from tb_goods05 where 进价!>1500



use db_mrsql
select * from tb_goods05 where 进价!<1200


use db_mrsql
select * from tb_goods05 where 商品名称 <> '冰箱'
select * from tb_goods05 where 商品名称 != '冰箱'



use db_mrsql
select * from tb_goods05 where 进价 between 1200 and 3000



use db_mrsql
select * from tb_landing07
select * from tb_landing07 where 登录时间 between
convert(varchar(10),DATEADD(DAY,-1,GETDATE()),120) and
 convert(varchar(10),GETDATE(),120)

 
 
 use db_mrsql
select * from tb_goods05 where 进价 not between 2000 and 3000



use db_mrsql
select * from tb_commodity05
select * from tb_commodity05 where 商品名称 = '电脑' or 商品名称 = '手机'



use db_mrsql
select * from tb_goods05
select * from tb_goods05 where not 商品名称='电脑'



use db_mrsql
select * from tb_goods05
select * from tb_goods05 where 商品名称='冰箱'OR 商品名称='电脑'AND 进价=3000
select * from tb_goods05 where (商品名称='冰箱'OR 商品名称='电脑')AND 进价=3000



use db_mrsql
select * from tb_landing07
select 编号,登录名,密码,convert(nvarchar(10),登录时间,120) as 登录时间 
from tb_landing07



use db_mrsql
select * from tb_average07
select 编号,姓名,convert(decimal(10,2),平均分数) as 平均分数 from tb_average07



use db_mrsql
select * from tb_average07
select 编号,ltrim(姓名) as 姓名 ,平均分数 from tb_average07


use db_mrsql
select * from tb_commodity05
select * from tb_commodity05 where 
商品价格 < 5000 and 商品价格 > 1500


use db_mrsql
select * from tb_landing07
select * from tb_landing07 where 登录时间 
between '2013-3-15' and '2013-3-16'


use db_mrsql
select * from tb_individualInfo05
select distinct 职业  from tb_individualInfo05

