use db_mrsql      --使用db_mrsql数据库
/*使用select关键字查询药品销售表tb_sell03，
并且使用order by关键字按照“药品编号”的降序排列该中的相关信息*/
select * from tb_sell03 order by 药品编号 desc 	


USE db_mrsql --使用db_mrsql数据库
/*使用sp_addtype创建用来存储邮政编码信息的postalcode用户定义数据类型*/
EXEC sp_addtype mrVarChar,'varchar(20)','not null'	


use db_mrsql  --使用db_mrsql数据库
declare @class varchar(20)  --声明一个局部变量                                                            
select  @class=所在班级  
from tb_student03 
where 学生姓名='张力心' 
--使用print关键字显示局部变量的值	      
print '张力心同学所在班级为:'+@class    


use db_mrsql--使用db_mrsql数据库
--使用@@identity显示插入“学生编号”的数值情况
insert into tb_Student03 
values('齐小强','男','4104班','80')
select @@identity as '学生编号' 	


USE db_mrsql --使用db_mrsql数据库
declare @A int ,@B int,@C int  --声明3个整型变量
/*--使用select关键字为变量@A和变量@B分别赋值为“30”和“80”*/
select @A=30,@B=80         
--使用SET关键字为变量@c赋值，将变量@A对@B取余的结果赋给变量@C
set @C=@A%@B
print @C  --使用print关键字显示变量@C的信息内容


use db_mrsql --使用db_mrsql数据库
DECLARE @studentname  char(20)  --使用declare声明一个变量
--使用set关键字为@studentname变量赋值为“Jim”
SET @studentname='Jim'  
print '字符串的值为:'+@studentname


USE db_mrsql --使用db_mrsql数据库
DECLARE @studentname char(20) --使用declare声明一个变量
SELECT @studentname='Luck'  --使用select关键字为该变量赋值
print @studentname     --使用print关键字输出变量的值


use db_mrsql  --使用db_mrsql数据库
/*查询“所在班级”为“4108班”并且
“学生成绩”大于“60”分的学生的基本信息*/
select *
from tb_student03
where 所在班级='4108班' and 学生成绩>'60'	


use db_mrsql --使用db_mrsql数据库
GO
--使用declare关键字声明3个变量
declare @x varchar(20),@y varchar(20),@z varchar(20)
set @x='你好！'  --将变量@x赋值为“你好！”
set @y='世界！'  --将变量@y 赋值为“世界！” 
print '两个变量交换前：'   --使用print关键字输出一句话
print @x                 --使用print关键字将变量@x输出
print @y                 --使用print关键字将变量@y输出
begin                    --在BEGIN…END语句中完成把两个变量的值交换   
  set @z=@x            
  set @x=@y
  set @y=@z
end
print '两个变量交换后：'   --使用print关键字输出一句话
print @x                 --使用print关键字输出一个变量@x
print @y   	--使用print关键字输出一个变量@y
