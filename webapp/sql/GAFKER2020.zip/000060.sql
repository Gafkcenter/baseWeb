use db_mrsql--使用db_mrsql数据库
GO
--查询修改教师信息表“tb_teacher06”前的数据表中的信息
select * from tb_teacher06
GO
/*将教师信息表“tb_teacher06”中的所有
教师备注字段中的信息修改为“对待工作认真负责！”*/
update tb_teacher06 set 
教师备注='对待工作认真负责！'
GO
--查询修改教师信息表“tb_teacher06”后的数据表中的信息
select * from tb_teacher06
GO




use db_mrsql--使用db_mrsql数据库
GO
--查看车辆数据表tb_car04中的信息情况
select * from tb_car04
GO
/*修改“车辆编号”为“1001”的信息
的“备注”的信息内容为"这是一部好车！"*/
update tb_car04 set 备注='这是一辆好车！'
where 车辆编号=1001 
GO
--查看修改后的表中的信息情况
select * from tb_car04



use db_mrsql--使用db_mrsql数据库
--查询修改前的数据表"tb_stuscore06"中的数据
select * from tb_stuscore06
--使用UPDATE语句中带有TOP子句,即修改前两条数据的信息
update top(2) tb_stuscore06 set 学生备注='是一名好学生！'
--查询修改后的数据表"tb_stuscore06"中的数据
select * from tb_stuscore06   



use db_mrsql    --使用db_mrsql数据库
GO
--判断“tb_memberCard04”信息表是否存在，如果存在将该信息表删除
      if exists(select * from INFORMATION_SCHEMA.TABLES 
        where table_name = 'tb_memberCard04')
        drop table tb_memberCard04  --删除该信息表
GO
--创建数据表 
create table tb_memberCard04
(
 会员编号 int,
 会员姓名 varchar(20),
 会员卡积分 float,
 会员卡等级 varchar(20)
)
--向tb_memberCard04数据表中的信息
insert into tb_memberCard04 values(1,'于洋',30,'银卡')
insert into tb_memberCard04 values(2,'王雪',80,'金卡')
insert into tb_memberCard04 values(3,'张波',120,'vip')
insert into tb_memberCard04 values(4,'齐春苗',140,'vip')
GO
--查询插入数据后的表中的信息的情况
select * from tb_memberCard04 
--修改数据表中的信息 
update tb_memberCard04 
set 会员卡积分=会员卡积分+
   (select 会员卡积分 
    from  tb_memberCard04
    where 会员编号='1'   
   )
where 会员卡等级='vip'
--查询修改后的数据表中的信息
select * from tb_memberCard04



use db_mrsql--使用db_mrsql数据库
GO
--修改数据表中的信息 
update tb_memberCard04 
set 会员卡积分=会员卡积分+
   (select 会员卡积分 
    from  tb_memberCard04
    where 会员卡等级='vip'   
   )
where 会员卡等级='vip'
--查询修改后的数据表中的信息的情况
select * from tb_memberCard04 



use db_mrsql --使用db_mrsql数据库
--查询会员基本信息表“tb_hy04”中的信息情况
select * from tb_hy04
--查询会员卡基本信息表“tb_hycard04”中的信息情况
select * from tb_hycard04
GO
--使用连接查询来修改会员卡基本信息表中的信息
 update tb_hycard04
 set 卡中金额=卡中金额+
 (
     select tb_hy04.会员积分 from tb_hy04 inner join 
     tb_hycard04 on tb_hy04.会员编号=tb_hycard04.会员编号   
  )
 where tb_hycard04.会员编号=1001
GO
--查询修改后的会员卡基本信息表中的信息情况
select * from tb_hycard04



use db_mrsql--使用db_mrsql数据库
GO
--查询数据表中的信息内容
select * from tb_money04
--修改“tb_money04”信息表
update tb_money04 set 基本工资=基本工资+50,浮动奖金=浮动奖金+100
where 工人编号 in 
(
select 工人编号 
from tb_work04 where 
工人编号=tb_money04.工人编号 and 职务='财会'
)
--查询修改后的数据表中的信息内容
select * from tb_money04



use db_mrsql--使用db_mrsql数据库
--查询赋值前的数据表“tb_login06”中的信息
select * from tb_login06
/*使用UPDATE为表中的所有行中的数据赋值(即：修改编号的值)*/
declare @i as int;
set @i=1000;
update tb_login06 set @i=编号=@i+1
--查询赋值后的数据表“tb_login06”中的信息
select * from tb_login06



use db_mrsql--使用db_mrsql数据库
--查询赋值前的数据表“tb_person06”中的信息
select * from tb_person06
/*使用UPDATE为表中的所有行中的数据赋值(即：修改人员备注的值)*/
declare @i as varchar(50);
set @i='暂无备注！';
update tb_person06 set 人员备注=@i 
where 人员性别='男'
--查询赋值后的数据表“tb_person06”中的信息
select * from tb_person06



use db_mrsql--使用db_mrsql数据库
select * from tb_user06
declare @A as varchar(20);
set @A='123456';
update tb_user06 set userpwd=@A
where userid=1001
select * from tb_user06


use db_mrsql--使用db_mrsql数据库
GO
--查看更新数据前工资信息表“tb_wage05”中的数据
select * from tb_wage05
--第一步
update tb_wage05 
set  工资=工资*(1-0.08)
where 工资<1800 and 工资>800
--第二步
update tb_wage05
set 工资=工资*(1-0.1)
where 工资>1800
--查看更新后的工资信息表"tb_wage05"中的数据
select * from tb_wage05


use db_mrsql--使用db_mrsql数据库
--查看修改数据前的数据表中的信息
select * from tb_employee05
--修改指定日期字段内的数据
update tb_employee05
set 员工性别='女'
where 员工生日='1988-02-16'
--查看修改数据后的数据表中的信息
select * from tb_employee05


use db_mrsql--使用db_mrsql数据库
--查看修改数据前的数据表中的信息
select * from tb_employee05
--修改指定int字段类型内的数据
update tb_employee05
set 员工姓名='王雪'
where 员工编号='1004'
--查看修改数据后的数据表中的信息
select * from tb_employee05



use db_mrsql--使用db_mrsql数据库
--查看修改数据前的数据表中的信息
select * from tb_employee05
--修改指定int字段类型内的数据
update tb_employee05
set 工资金额='1200'
where 员工姓名='王涛'
--查看修改数据后的数据表中的信息
select * from tb_employee05


use db_mrsql--使用db_mrsql数据库
--查看修改数据前的数据表中的信息
select * from tb_employee05
--修改指定int字段类型内的数据
update tb_employee05
set 员工姓名='jim'
where 工资金额='1000'
--查看修改数据后的数据表中的信息
select * from tb_employee05



use db_mrsql--使用db_mrsql数据库
GO
--判断员工信息表“tb_yuangong04”是否存在，如果存在将该信息表删除
      if exists(select * from INFORMATION_SCHEMA.TABLES 
        where table_name = 'tb_yuangong04')
          drop table tb_yuangong04  --删除员工信息表
GO
--创建员工基本信息数据表
create table tb_yuangong04
(
  员工编号 int,  
  员工姓名 varchar(20),
  家庭住址 varchar(50),
  备注 text
)
--向表中插入一条数据
insert into tb_yuangong04 values(1001,'张明慧','吉林省长春市','无')
--查询插入后的数据信息
select * from tb_yuangong04
--删除员工信息表“tb_yuangong04”中的所有数据
delete from tb_yuangong04
--查询删除数据后的信息
select * from tb_yuangong04




use db_mrsql--使用db_mrsql数据库
/*查询删除员工数据表“tb_work06”
之前数据表中的信息*/
select * from tb_work06
/*删除员工信息表“tb_work06”
中家庭住址为吉林省长春市的信息*/
delete from tb_work06 
where 家庭住址='吉林省长春市'
/*查询删除员工数据表“tb_work06”
之后数据表中的信息*/
select * from tb_work06



use db_mrsql--使用db_mrsql数据库
GO
--判断商品销售信息表“tb_sell04”是否存在，如果存在将该信息表删除
      if exists(select * from INFORMATION_SCHEMA.TABLES 
        where table_name = 'tb_sell04')
        drop table tb_sell04  --删除商品信息表
GO
--创建商品销售信息表“tb_sell04”
create table tb_sell04
( 
  商品编号 int identity(1001,1),
  商品名称 varchar(20),
  销售数量 int,
  商品说明 text
)
GO
--向该信息表中插入信息
insert into tb_sell04 values('上衣',100,'无')
insert into tb_sell04 values('毛衣',80,'新品上市！')
--查询插入前的数据的信息
select * from tb_sell04
--删除商品名称为“毛衣”的这条数据信息
delete from tb_sell04 where 商品名称='毛衣'
--查询删除后的表中的数据信息
select * from tb_sell04



use db_mrsql--使用db_mrsql数据库
--查询数据表tb_score04的数据信息
select * from tb_score04
--删除学生编号为“1002”学生姓名为“王晓佳”的重复的两条数据
delete  from tb_score04 
where 学生编号=1002 and 学生姓名='王晓佳'
--查询删除信息后的数据表中的信息
select * from tb_score04    



 use db_mrsql--使用db_mrsql数据库
GO
--判断tb_num04信息表是否存在，如果存在将该信息表删除
      if exists(select * from INFORMATION_SCHEMA.TABLES 
        where table_name = 'tb_num04')
        drop table tb_num04  --删除该信息表
GO
--创建数据表
create table tb_num04
(
  编号 int identity(1,1),
  姓名 varchar(20)
)
--向表中插入数据信息
insert into tb_num04 values('李春梅')
insert into tb_num04 values('王雪健')
insert into tb_num04 values('李春梅')
--查询插入数据信息后的数据表中的信息
select * from tb_num04
--删除tb_num04中的部分重复行
Delete from tb_num04 where 编号 not in 
(select max(编号) from tb_num04 group by 姓名)
--查询删除tb_num04中的部分重复行后的数据表中的信息
select * from tb_num04  



use db_mrsql   --使用db_mrsql数据库 
--利用TRUNCATE TABLE语句删除登录信息表“tb_login04”中的数据的信息      
truncate table tb_login04 



use db_mrsql--使用db_mrsql数据库
--查询删除信息前的数据表"tb_stuscore06"中的数据
select * from tb_stuscore06
/*删除数据表中的前条数据的信息*/
delete top(3) tb_stuscore06 
--查询删除后的数据表"tb_stuscore06"中的数据
select * from tb_stuscore06  



use db_mrsql--使用db_mrsql数据库
--查看修改数据前的数据表中的信息
select * from tb_employee05
--删除指定字段为空记录的记录的信息
delete from tb_employee05 
where 员工性别 is null and 工资金额 is null
--查看修改数据后的数据表中的信息
select * from tb_employee05 



use db_mrsql--使用db_mrsql数据库
--查询“tb_hy06”数据表中的信息
select * from tb_hy06
GO
--使用create view语句基于“tb_hy06”创建一个视图
create view view_hy06
as 
select * from tb_hy06 where 性别='女'
GO
--查看更新视图之前视图中的数据
select * from view_hy06
GO 
--查看更新视图之前数据表中的数据
Select * from tb_hy06
--通过视图更新表和视图中的数据
update view_hy06 
set 编号='1000'+编号
where 姓名='王思齐'
--查看更新视图后视图中的数据
select * from view_hy06
--查看更新视图后数据表中的数据
select * from tb_hy06




use db_mrsql--使用db_mrsql数据库
--查询更新前的表中的数据
select * from tb_hy06
/*更新表中的数据*/
delete from view_hy06 where 姓名='李强'
--查询更新后的表中的数据
select * from tb_hy06
