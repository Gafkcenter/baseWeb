use db_mrsql      --使用db_mrsql
declare @m int     --使用declare关键字声明一个整型变量“@m”
set @m=-24        --使用set关键字将该变量赋值为“-24”
if @m<0           --利用IF条件选择语句判断该变量的值是否是负数
print '@m是一个负数'--使用print关键字输出一句话


use db_mrsql--使用db_mrsql
declare  @A int   --使用declare声明一个整型变量
set @A=7        --使用set关键字将数字8赋值给变量@A
if @A % 2<>0    --如果变量@A对数字2取余不等于0
--使用print关键字输出一句话为"@A变量是一个奇数!"
 print  '@A变量是一个奇数!'  
else            --如果变量@A对数字2取余等于0
--使用print关键字输出一句话为"@A变量是一个偶数!"
 print  '@A变量是一个偶数!'    	



use db_mrsql--使用db_mrsql
declare  @m int,@n int --使用declare声明2个变量@m和@n
set @m=20           --使用set将数字20赋值给变量@m
set @n=30           --使用set将数字30赋值给变量@n
if @m<@n            --判断变量@m是否小于@n 
--如果@m比@n小，输出一句话“变量@m大于变量@n”
    print '变量@m大于变量@n' 
else 
--如果@m比@n大，输出一句话“变量@m不大于变量@n”
    print'变量@m不大于变量@n'


use db_mrsql--使用db_mrsql数据库
--使用declare关键字声明两个整型变量@A和@B
declare  @A int,@B int  
set @A=-7
set @B=-7
if @A>0    --变量@A大于0
  if @B>0  --变量@B大于0
--使用print关键字输出一句话"@A@B位于第一象限"
     print'@A@B位于第一象限'
  else     --变量@B小于0
--使用print关键字输出一句话"@A@B位于第四象限"     
     print'@A@B位于第四象限'
else       --变量@A小于0 
  if @B>0  --变量@B大于0
--使用print关键字输出一句话"@A@B位于第二象限"
     print'@A@B位于第二象限'
  else    --变量@B小于0
--使用print关键字输出一句话"@A@B位于第三象限"
     print'@A@B位于第三象限'


USE pubs --使用pubs数据库
/*使用带有简单CASE 函数的SELECT语句统计titles数据表信息情况*/
SELECT kind = 
      CASE type
         WHEN 'popular_comp' THEN 'Popular Computing'
         WHEN 'mod_cook' THEN 'Modern Cooking'
         WHEN 'business' THEN 'Business'
         WHEN 'psychology' THEN 'Psychology'
         WHEN 'trad_cook' THEN 'Traditional Cooking'
         ELSE 'Not yet categorized'
      END,
   CAST(title AS varchar(30)) AS 'Shortened Title',
   price AS Price
FROM titles
WHERE price IS NOT NULL
ORDER BY type, price
COMPUTE AVG(price) BY type  


USE pubs  --使用pubs数据库
SELECT    'Price Kind' = 
      CASE 
         WHEN price IS NULL THEN 'Not yet priced'
         WHEN price < 20 THEN 'Very Reasonable Title'
         WHEN price >= 20 and price < 20 THEN 'Coffee Table Title'
         ELSE 'Expensive book!'
      END,   
   CAST(title AS varchar(20)) AS 'Shortened Title'
FROM titles
ORDER BY price


use db_mrsql  --使用db_mrsql数据库
--使用declare关键字声明两个整型变量“@S”和变量“@sum”
declare  @S int,@sum int 
--使用set关键字为这两个变量分别赋值
set @S=1      
set @sum=0
while @S<=100
begin  
set @sum=@sum+@S
set @S=@S+1
end
print @sum --使用print关键字将变量@sum输出	

use db_mrsql  --使用db_mrsql数据库
--使用declare关键字声明两个整型变量“@A”和变量“@S”
declare @A int,@S int
--使用SET关键字将数字1赋给变量@A
set @A=1
--使用SET关键字将数字0赋给变量@S
set @S=0
while @A<15
 begin
   set @A=@A+1--使用SET关键字将变量@A与1的和赋给变量@A
  if @A%2=0 --使用IF关键字判断变量@A和2相除后的余数是否等于0
   set @S=@S+@A--使用SET关键字将变量@S与变量@A相加的和赋给变量@S
  else
    continue
----使用print关键字输出一句话"只有当@A是偶数时才输出这句话"
    print '只有当@A是偶数时才输出这句话'
 end 
print @S --使用print关键字将变量@S输出

use db_mrsql    --使用db_mrsql数据库
declare @x int   --使用DECLARE关键字声明一个变量  
set @x=3       --使用SET关键字将数字3赋给变量@x                                
if @x>0        --使用IF关键字判断变量@x是否大于0
--如果变量@x大于0,则用print关键字输出一句话"碰到return语句之前!"
 print'碰到return语句之前!'  
return
--如果变量@x大于0,则用print关键字输出一句话"碰到return语句之后!"
 print'碰到return语句之后!' 


use db_mrsql          --使用db_mrsql数据库
declare @M int        --使用DECLARE关键字声明一个整型变量@M                                      
select @M=50        --使用SELECT关键字将数字50赋给变量@M
HI:
    print @M        --使用print关键字将变量@M输出
    select @M=@M+1 --使用SRLECT关键字将变量@M与1的和赋给变量@M
while @M<=51
goto HI
