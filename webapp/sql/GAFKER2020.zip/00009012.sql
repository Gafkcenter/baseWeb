use db_mrsql
select  * 
from tb_book12,tb_book_author12


use db_mrsql
select a.tb_book_id,a.book_name,a.book_number,a.book_price,b.tb_book_author,b.tb_author_department,c.tb_author_resume
from tb_book12 a,tb_book_author12 b,tb_books_author12 c
where a.tb_book_author=b.tb_book_author and b.tb_book_author=c.tb_book_author


use db_mrsql
select *
from  tb_book12 join tb_book_author12 join tb_books_author12
on tb_books_author12.tb_book_author=tb_book_author12.tb_book_author
on tb_book_author12.tb_author_department=tb_book12.book_sort


use db_mrsql
select tb_book12.* ,tb_book_author12.tb_author_resume
from tb_book12,tb_book_author12,tb_books_author12
where 
   tb_book12.book_price>75 
and
   tb_book12.tb_book_author=tb_book_author12.tb_book_author 
and 
   tb_book_author12.tb_author_department=tb_books_author12.tb_author_department

   
   
   use db_mrsql
select tb_book12.* 
from tb_book12,tb_book_author12,tb_books_author12
where tb_book12.tb_book_author=tb_book_author12.tb_book_author and tb_book_author12.tb_book_author=tb_books_author12.tb_book_author


use db_mrsql
select a.* 
from tb_book12 as a,tb_book_author12 as b,tb_books_author12 c
where a.tb_book_author=b.tb_book_author and b.tb_book_author=c.tb_book_author



use db_mrsql
select tb_book_author12.*,tb_book12.*
from tb_book_author12,tb_book12
where tb_book_author12.tb_book_author=tb_book12.tb_book_author


use db_mrsql
select tb_book12.book_name,tb_book12.book_number,tb_book12.book_price,tb_book_author12.*
from tb_book12,tb_book_author12
where tb_book_author12.tb_book_author_id>tb_book12.tb_book_id




use db_mrsql
select tb_book12.tb_book_id,tb_book12.tb_book_author,tb_book12.book_name,tb_book12.book_sort,tb_book12.book_number,tb_book_author12.tb_author_resume
from tb_book12 inner join tb_book_author12
on tb_book_author12.tb_book_author=tb_book12.tb_book_author


use db_mrsql
select fullname as 商品名称, tsum1 as 进货金额 
from (
    select a.tradecode, a.fullname,a.averageprice, b.qty1, b.tsum1 
    from tb_stock13 a inner join (
	select sum(qty) as qty1,sum(tsum) as tsum1, fullname 
        from tb_warehouse_detailed13
        group by fullname) b on a.fullname = b.fullname 
where (a.price > 0 )) tb1



use db_mrsql
select a.tb_book_id,a.book_name,a.book_number,a.book_price,b.tb_book_author,b.tb_author_department,b.tb_author_resume
from tb_book12 a left join tb_books_author12 b
on a.tb_book_author=b.tb_book_author


use db_mrsql
select a.tb_book_id,a.book_name,a.book_number,a.book_price,b.tb_book_author,b.tb_author_department,b.tb_author_resume
from tb_book12 a right join tb_books_author12 b
on a.tb_book_author=b.tb_book_author



use db_mrsql
select a.tb_book_id,a.book_name,a.book_number,a.book_price,b.tb_book_author,b.tb_author_department,b.tb_author_resume
from tb_book12 a full join tb_books_author12 b
on a.tb_book_author=b.tb_book_author



use db_mrsql
select tb_employee13.序号, tb_employee13.员工编号, 
        tb_employee13.员工姓名, tb_laborage13.薪资编号, 
        tb_laborage13.月份, tb_laborage13.基本工资, 
        tb_job13.请假天数, tb_job13.扣除金额 
from  (tb_employee13 left join tb_job13 
                      on tb_employee13.员工编号=tb_job13.员工编号) 
       left join tb_laborage13 
         on tb_employee13.员工编号=tb_laborage13.员工编号

		 
		 
		 use db_mrsql
select  a.book_name,b.book_price 
from tb_book12 a inner join tb_book12 b
on  a.tb_book_id=b.tb_book_id
where a.book_sort=b.book_sort


use db_mrsql
select  a.book_name,a.book_price,a.book_number,b.tb_author_department,b.tb_author_resume  
from tb_book12 a cross join tb_books_author12 b  




