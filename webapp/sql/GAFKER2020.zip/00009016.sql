CREATE FUNCTION NUMTOSTR
(@NUM INT)
RETURNS NVARCHAR(3)
AS
BEGIN
	DECLARE @STR NVARCHAR(3)
	IF @NUM>=85
		SET @STR='优'
	ELSE
	IF @NUM>=75
		SET @STR='良'
	ELSE
	IF @NUM>=60
		SET @STR='及格'
	ELSE
	IF @NUM<60
		SET @STR='不及格'
	RETURN @STR
END




create function find(@x float)
returns table 
as 
return(select * from tb_course12 where 课程成绩>@x)



create function dbo.info()
returns @xsry table(学号 int primary key,
姓名 varchar(10),
课程代码 int)
as
begin
declare @ordernum
table(学号 int,课程代码 int)
insert @ordernum select 学号,课程代码 from tb_course12
insert @xsry select a.学号,a.姓名,b.课程代码 
from db_studets12 as a left join @ordernum as b on a.学号=b.课程代码
return
end




select 课程成绩,dbo.numtostr(课程成绩) as 成绩等级  from tb_course12



USE db_mrsql
GO
EXEC sp_helptext find
EXEC sp_depends find
EXEC sp_help find
GO



alter function find(@x float)
returns table
as
return(select * from tb_course12 where 课程成绩<@x)
use db_mrsql
select * from find (60)




