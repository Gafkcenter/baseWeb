use db_mrsql
go
 create trigger tri_emp on tb_employee13
 for insert 
 as
   declare @id int,@name varchar(8)
   select @id = 编号,@name = 姓名 from inserted
   insert into tb_laborage13(编号,姓名,基本工资,奖金) values(@id,@name,0,0)
go   	



use db_mrsql
   go
   /*创建触发器*/
   create trigger del_student on tb_student13
    for delete as
      print '学生信息已经删除'
   /*执行删除操作*/ 
  go 
   delete from tb_student13 where 编号 = 3	

   
   
   use db_mrsql
 go
  create trigger tri_update_emp on tb_employee13
  for update 
  as
   declare @id int,@name varchar(8)
   select @id = 编号 from deleted
   select @name = 姓名 from inserted
   update tb_laborage13 set 姓名 = @name where 编号 = @id   
  go

  
  
  use db_mrsql
 go
   create trigger c_student
     on tb_student13  for update as 
   begin
     /*将DELETE表中存放的记录存入tb_studentinfo13表中*/ 
     insert into tb_studentinfo13(类型,时间,编号,姓名,性别,年龄,班级)
     select '修改前',getdate(),del.编号,del.姓名,del.性别,del.年龄,del.班级
     from deleted as del
     /*将INSERT表中存放的记录存入tb_studentinfo13表中*/
     insert into tb_studentinfo13(类型,时间,编号,姓名,性别,年龄,班级)
     select '修改后',getdate(),ins.编号,ins.姓名,ins.性别,ins.年龄,ins.班级
     from inserted as ins
   end

   
   
   use db_mrsql
go
 create trigger t_laborage 
   on tb_laborage13
   for delete ,insert as
 declare @id int ,@name varchar(8)
 select @id = 编号 ,@name = 姓名 from deleted
   if(@id in(select 编号 from tb_employee13 where 姓名 = @name))
      begin
        rollback transaction
        print '员工信息在员工表中存在，不允许删除'
      end
  declare @sid int,@sname varchar(8)
  select @sid = 编号,@sname = 姓名 from inserted
    if(@sid not in(select 编号 from tb_employee13)) 
    begin 
     rollback transaction
     print '此职工在员工表中不存在，请审核后再输入'
    end

	
	
	use db_mrsql
  go
 create trigger t_employee
 on tb_employee13
  for update as
   if(columns_updated()&3>0)  /*第一列或第二列被更新，掩码“11”用十进制表示即为“3”*/ 
      begin 
        print '编号列与姓名列不允许被更改'
        rollback transaction
      end

	  
	  
	  use db_mrsql
 go
/*为tb_stu13表创建DELETE 触发器stu_delete*/
 create trigger stu_delete
 on tb_stu13
 for delete as
  declare @rowcount int
  select @rowcount = @@rowcount /*记录删除所涉及的行数*/
    if @rowcount > 1
      begin 
        print '一次只能删除一条记录'
        rollback transaction   /*回滚操作*/
      end
    else
      declare @id varchar(10)          /*从tb_score13表中删除对应的记录*/
      select @id = 学号 from deleted
      delete from tb_score13 where 学号=@id
go
/*为tb_score表创建DELETE触发器*/
create trigger lab_delete on tb_score13                                            
 for delete as                                                                  
  declare @score varchar(10) 
  select @score = 语文  from deleted                             
  if(@score  > 90)             /*判断工资是否大于1000*/
   begin 
     rollback transaction     /*回滚操作*/
     print '不允许删除该记录'
   end
  else                                                                    
    print '记录已删除'

	
	
	use db_mrsql
go
  create trigger delete_employee
   on tb_emp13
    after delete as
       declare @rowcount int
       select @rowcount = @@rowcount
  if @rowcount>1
       begin
          rollback transaction
       print('当前删除的记录条数大于一条，一次只允许删除一条')
       end
  if @rowcount=1
      begin
          declare @所属部门 varchar(10) 
          select @所属部门 = 所属部门 from deleted
      delete from tb_emp13 where 所属部门 = @所属部门                                                 
      end
     print '不允许删除该记录'

	 
	 
	 
	 use db_mrsql
  go
 create trigger tri_book
   on v_book
 instead of insert as
   begin 
     declare @编号 varchar(10)
     select @编号 = substring(编号,1,1) from inserted
     if @编号 = 'j'		/*如果编号是以"j"开头，则将信息插入tb_javabook13表中*/
       begin
         insert into tb_javabook13 select 编号,书名,定价 from inserted
         return
       end
     if @编号 = 's'		/*如果编号是以"s"开头，则将信息插入tb_sqlbook13表中*/
        begin
         insert into tb_sqlbook13 select 编号,书名,定价 from inserted
         return
       end
      if @编号 = 'a'	/*如果编号是以"a"开头，则将信息插入tb_aspbook13表中*/
        begin
         insert into tb_aspbook13 select 编号,书名,定价 from inserted
         return                                                                                          
        end
      else
        begin                                                                                  
         rollback transaction
         print '请确认编号后再输入！'
        end
     end

	 
	 
	 use db_mrsql
go
/*创建tb_mr_emp13表*/
create table tb_mr_emp13
  ( data datetime,
    mr_id varchar(8),
    state varchar(20),
    mr_name varchar(30)
   )
go
/*为tb_emp13表创建触发器tri_emp_jl*/
 create trigger tri_emp_jl on tb_emp13
  for insert,update
 as
  declare @id varchar(4)
  select @id = 编号 from inserted
  if update(姓名)     /*判断修改的列是否为“姓名”列*/
   insert into tb_mr_emp13 values(getdate(),@id,'修改员工姓名',user_name())

   
   
   
   use db_mrsql
exec sp_helptrigger tb_emp13
exec sp_depends tb_emp13



use db_mrsql
/*创建触发器*/
  go
  create trigger tri_emp
  on tb_emp13
   for insert 
  as
   select * from tb_emp13
/*修改触发器*/
  go
  alter trigger tri_emp on tb_emp13
    for insert ,update ,delete
    as
      select * from tb_emp13

	  
	  
	  use db_mrsql
  go
  alter table tb_emp13
  disable trigger t_emp  

  
  
  use db_mrsql
  go
  create trigger insert_courses
   on tb_teacher13 for insert
  as
   /*定义变量@c_name、@t_name*/
   declare @c_name varchar(10),@t_name varchar(10)
   /*将变量赋值*/
   select @c_name = 所授课程 ,@t_name = 姓名 from inserted
  insert into tb_courses13(课程名称,教师)values (@c_name,@t_name)

  
  
  use db_mrsql
  go
    create trigger upda_stu
    on tb_stu13 for update as
    declare @id varchar(10)
    select @id = 学号 from deleted
   begin  
    if update(姓名)
    delete from tb_score13 where 学号 = @id
    print 'tb_score13表中没有对应的数据，请录入'
    print @id
   end        

   
   use db_mrsql
  go
    create trigger tri_delete_laborage
    on tb_employee13 for delete
    as
     declare @id int,@name varchar(8)
     select @id = 编号,@name = 姓名 from deleted
     delete tb_laborage13 where 编号 = @id and 姓名 = @name
  go

  
  
  
  create or replace trigger tr_emp						/*创建触发器*/
  before update or insert on tb_emp					/*设置触发事件*/
 for each row									/*指明每次更新一行都将激活触发器*/
   begin
     if inserting then								/*判断触发事件*/
         dbms_output.put_line('信息添加成功');		/*输出的提示信息*/
     end if;
     if updating then	
         dbms_output.put_line('信息修改成功');
     end if;
   end;

   
   
   create trigger tri_login					/*创建触发器*/
   after create on schema					/*指定触发动作*/
   begin
    insert into tb_login values(user,'创建表');
   end;

   
   
   create trigger tr_stu
before insert on tb_stu
for each row
set new.name = ‘mrsoft’

  