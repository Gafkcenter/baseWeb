use db_mrsql
select tb_book_author,tb_author_department,
	(select max(book_price)
		from tb_book12 
		where tb_book12.tb_book_author=tb_book_author12.tb_book_author),
	tb_book_author_id,tb_author_resume
	from tb_book_author12;

	
	use db_mrsql
select 姓名,工资,所属部门
from tb_laborage12
where 工资 in (select max(工资)
		from tb_laborage12
		group by 所属部门)
and 
      所属部门 in (select distinct 所属部门
		from tb_laborage12 
)


use db_mrsql
select * 
from tb_book_author12
where tb_book_author_id>(
	select tb_book_id
	from tb_book12
	where book_price=78
)



use db_mrsql
select 姓名,工资,所属部门
from tb_laborage12
where 工资>(
	select avg(工资)from tb_laborage12)

	
	use db_mrsql
select 姓名,工资,所属部门
from tb_laborage12
where 工资 in (
	select max(工资) 
	from tb_laborage12
	group by 所属部门)
and 所属部门<>'PHP'
and 所属部门 not like 'JSP'


use db_mrsql
select * 
from tb_book12
where book_sort not in (
	select tb_author_department 
	from tb_book_author12
)



use db_mrsql
select 姓名,工资,所属部门
from tb_laborage12
where 工资 <all (
	select avg(工资) 
	from tb_laborage12
	group by 所属部门)

	
	
	use db_mrsql
select 姓名,工资,所属部门
from tb_laborage12
where 工资 >any (
	select avg(工资) 
	from tb_laborage12
	group by 所属部门)

	
	
	use db_mrsql
select * 
from tb_book12
where exists (
	select tb_author_department 
	from tb_book_author12
	where tb_book12.book_sort=tb_book_author12.tb_author_department)
order by tb_book12.book_price



use db_mrsql
select * 
from tb_book12
where not exists(
	select tb_author_department
	from tb_book_author12
	where tb_book12.book_sort=tb_book_author12.tb_author_department )

	
	
	use db_mrsql
select * 
from tb_book12 
where book_sort in (
	select tb_author_department
	from tb_book_author12 
	where tb_book12.tb_book_id=tb_book_author12.tb_book_author_id )

	
	
	use db_mrsql
select * 
from tb_book12 
where book_sort not in (
	select tb_author_department
	from tb_book_author12 
	where tb_book12.tb_book_id=tb_book_author12.tb_book_author_id )

	
	
	use db_mrsql
select *
from tb_book12
where book_price=(
	select max(book_price) from tb_book12	
)



use db_mrsql
select *
from tb_book12
where book_sort='PHP' and book_price>(
	select avg(book_price)
	from tb_book12
	where book_sort='PHP'
)



use db_mrsql
select book_number,book_name,book_price,book_sort
from tb_book12
where book_sort='PHP'
group by book_number,book_name,book_price,book_sort
having avg(book_price)>(
	select min(book_price)
	from tb_book12
)
order by book_price



use db_mrsql
select book_number
from tb_book12 s1
where not exists (
	select * 
	from tb_book12 s2
	where s2.book_number='1001-100-102' and not exists(
		select * 
		from tb_book12 s3
		where s3.book_number=s1.book_number and s3.tb_book_author=s2.tb_book_author  
	)
)


use db_mrsql
select * 
from tb_mr_wages12 
where 工资月份=3 AND 人员姓名 IN( 
      select 负责人 
      from tb_mr_department12 
      where 负责人 IN(
           select 人员姓名 
           from tb_mr_staff12 
           where 学历='本科')) 
order by 人员编号


use db_mrsql
select * 
from tb_stu_score12 
where Math_Score < some ( 
     select Math_Score
     from tb_stu_score12 
     where name in( 
          select name
          from tb_stu_score12
          where id='2' or id='4'))

		  
		  
		  use db_mrsql
update tb_book12
set book_number='1001-101-101'
where book_sort in(
	select tb_author_department 
	from tb_book_author12
	where tb_book_author='王一'
)
select book_number from tb_book12



use db_mrsql
insert into tb_book_author12 (
    tb_book_author,tb_author_department,tb_author_resume
)(
    select tb_book_author,tb_author_department,tb_author_resume
    from tb_books_author12 )
select * from tb_book_author12



use db_mrsql
delete 
from tb_books_author12
where tb_book_author_id=(
	select tb_book_author_id 
	from tb_books_author12
	where tb_book_author_id='2'
)



use db_mrsql
select *
from tb_book_author12
intersect
select *
from tb_books_author12
order by tb_book_author_id


use db_mrsql
select *
from tb_book_author12
except
select *
from tb_books_author12
order by tb_book_author_id
select * from tb_book_author12
select * from tb_books_author12


use db_mrsql
select tb_book_author_id,tb_book_author,tb_author_department,tb_author_resume
from tb_book_author12
union
select tb_book_author_id,tb_book_author,tb_author_department,tb_author_resume 
from tb_books_author12



use db_mrsql
select tb_book_author_id,tb_book_author,tb_author_department,tb_author_resume
from tb_book_author12
union all
select tb_book_author_id,tb_book_author,tb_author_department,tb_author_resume 
from tb_books_author12



use db_mrsql
select tb_book_author as 图书作者,tb_author_department,tb_author_resume
from tb_book_author12
where tb_book_author_id=1
union all
select tb_book_author,tb_author_department,tb_author_resume 
from tb_books_author12
where tb_book_author_id=3



use db_mrsql
select tb_book_author,tb_author_department,tb_author_resume,'来自tb_book_author12表' as 数据来源
from tb_book_author12
union 
select tb_book_author,tb_author_department,tb_author_resume,'来自tb_books_author12表' 
from tb_books_author12


use db_mrsql
select *
from tb_book_author12
where tb_book_author_id=4
union all
select * 
from tb_book_author12
where tb_book_author_id!=4


use db_mrsql
with tb_book_price(book_sort,book_price)
as(
select tb_book12.book_sort,avg(tb_book12.book_price) as 平均价格
from tb_book12 
where tb_book12.book_sort='PHP'
group by book_sort
)
select max(book_price) as 平均价格 from tb_book_price


use db_mrsql
with x(部门编号,cnt,list,emps_id,length)  /*创建一个临时表x,包括5个字段*/
as(
select 部门编号,count(*) over (partition by 部门编号),
cast (员工姓名 as varchar (1000)),emps_id,1
from tb_emps12
union all	/*进行连接*/
select x.部门编号,x.cnt,cast(x.list+','+e.员工姓名 as varchar(1000)),e.emps_id,x.length+1
from tb_emps12 e,x
where e.部门编号=x.部门编号 and x.emps_id>e.emps_id )
select 部门编号,list
from x
where length=cnt
order by 1
/*为了更好的理解递归查询,这里给出了tb_emps09表的原始数据*/
select * from tb_emps12


