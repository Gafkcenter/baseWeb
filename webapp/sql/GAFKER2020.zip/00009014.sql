use db_mrsql
go
create view 视图5
as
select distinct 
      top 100 percent dbo.tb_staff14.id as ID, dbo.tb_staff14.number as 编号, 
      dbo.tb_staff_wages14.account as 账号, dbo.tb_staff_wages14.seniority as 工龄, 
      dbo.tb_staff_wages14.wages as 工资
from dbo.tb_staff14 inner JOIN
      dbo.tb_staff_wages14 on dbo.tb_staff14.id = dbo.tb_staff_wages14.id
where (dbo.tb_staff14.number = 1026)
go
exec sp_helptext'视图5'



use db_mrsql
go
create view 视图7 
as
select name,number,duty,department,tel
from tb_staff14



use db_mrsql
go
alter view 视图4(name,number)
as
select a.name,b.number
from dbo.tb_staff14 as a inner join dbo.tb_staff_wages14 as b on a.number=b.number
where a.number>1000 and a.number<9999
go 
exec sp_helptext '视图4'



use db_mrsql
exec sp_help 视图2
go



use db_mrsql
go
drop view 视图3,视图4
go



use db_mrsql
go
----创建视图
create view 视图9 
as 
select a.name,a.number,a.duty,a.department,b.account,b.seniority
from tb_staff14 as a inner join tb_staff_wages14 as b on a.number=b.number 
go
----添加数据
insert into 视图9(name,number,duty,department)
values('孙**','1029','程序员','PHP')
go
insert into 视图9(account,seniority)
values('220322****','1')
go



use db_mrsql
update 视图1 set name='李一' where number='1026'
go 
update 视图9 set seniority='2' where number='1015'



use db_mrsql
go
create view 视图10
as
select order_number,client_name,client_tel,client_postalcode
from tb_commodity14,tb_order14,tb_client14
where tb_commodity14.number=tb_order14.number and tb_order14.order_name=tb_client14.client_name
use db_mrsql
go
select client_name,client_tel,client_postalcode
from 视图10
where order_number='1001'





use db_mrsql
go
create view 视图11 
as
select client_name,client_tel
from tb_client14
where client_tel is not null
use db_mrsql
go
select * from 视图11



use db_mrsql
go
create view 视图11 
as
select client_name,client_tel
from tb_client14
where client_tel is not null
use db_mrsql
go
select * from 视图11





use db_mrsql
go
create view 视图13(item_number,description,order_ct,sold_ct,avg_sales_price,total_cost,total_sales,profit,pct_profit)
as
select 视图12.item,description,order_ct,sold_ct,avg_sales_price,sold_ct*item_cost,sold_ct*avg_sales_price,(avg_sales_price*sold_ct)-(sold_ct*item_cost),(((avg_sales_price*sold_ct)-(sold_ct*item_cost))/(sold_ct*item_cost))*100
from tb_item14,视图12
where tb_item14.item_number=视图12.item




use db_mrsql
go
create view 视图14
as 
select * from tb_order14 
where order_name='潘一'
with check option




use db_mrsql
go
create view 视图15
with encryption
as
select a.number,a.name,b.counts
from tb_commodity14 as a inner
join tb_marketing14 as b on a.number=b.number
go
exec sp_helptext '视图15'



use db_mrsql
go
create view 视图16
as
select number,name,specification,habitat,retail,wholesale
from tb_commodity14
go
use db_mrsql
select number,name,specification,habitat,retail,wholesale
from tb_commodity14
go



use db_mrsql
go
create view 视图17
as
select * from tb_marketing14
where counts>90
go
select * from 视图17



