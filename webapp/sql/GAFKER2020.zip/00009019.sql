/*启动隐性事务模式*/
SET IMPLICIT_TRANSACTIONS ON
GO
INSERT INTO tb_mrMember15 VALUES(1,'小贯红')
GO
INSERT INTO tb_mrMember15 VALUES(2,'大房伟')
GO
COMMIT TRANSACTION --提交事务
GO
/*下面的INSERT语句将开始第二个事务*/
INSERT INTO tb_mrMember15 VALUES(3,'小苏宇')
GO
SELECT * FROM tb_mrMember15
GO
COMMIT TRANSACTION --结束事务
GO 
/*关闭隐性事务模式*/
SET IMPLICIT_TRANSACTIONS OFF
GO



USE db_mrsql  --使用db_mrsql数据库
--查询数据表中的数据
SELECT * FROM tb_Stock15
GO
BEGIN TRANSACTION UPDATE_DATA
  UPDATE tb_Stock15 SET 库存数量 = 3000
  WHERE 商品编号 = '2008001'
  DELETE tb_Stock15 WHERE 商品名称 = '花生饮料'
COMMIT TRANSACTION UPDATE_DATA
GO
--查询修改和删除数据后的数据表中的数据
SELECT * FROM tb_Stock15



USE db_mrsql
GO
INSERT INTO tb_ShoppingSale15
(订单编号,图书名称) VALUES(1,'SQL参考大全')
INSERT INTO tb_ShoppingSale15
(订单编号,图书名称) VALUES(2,'SQL范例大典')
INSERT INTO tb_ShoppingSale15
(订单编号,图书名称) VALUES(2,'ASP.NET自学手册')
GO
SELECT * FROM tb_ShoppingSale15



USE db_mrsql
GO
SELECT * FROM tb_Operator15
BEGIN TRANSACTION INSERT_DATA --开始事务
  INSERT INTO tb_Operator15
  VALUES('2008008','夜枫冷','男')
COMMIT TRANSACTION INSERT_DATA --提交事务
GO
IF @@ERROR = 0 
  PRINT '数据添加成功！'
GO



USE db_mrsql
/*开始事务*/
BEGIN TRANSACTION
/*设置事务保存点*/
SAVE TRANSACTION SavePoint
INSERT INTO tb_BookSell15 VALUES(1001,'明日图书')
/*回滚到事务保存点*/
ROLLBACK TRANSACTION SavePoint



USE db_mrsql
/*开始事务*/
BEGIN TRAN Update_data
UPDATE tb_Customers03 SET 图书名称='ASP范例宝典'--修改操作
WHERE 图书编号='2008003'--条件
/*回滚事务*/
ROLLBACK TRAN Update_data --回滚事务
SELECT * FROM tb_Customers03




/*开始事务*/
BEGIN TRAN 
/*定义变量*/
DECLARE @now_time VARCHAR(8)
/*对表tb_mrBook15实行HOLKLOCK进行表级锁定*/
SELECT * FROM tb_mrBook15 WITH (HOLDLOCK)
SELECT @now_time = CONVERT(VARCHAR,GETDATE(),8)
/*显示加锁时间*/
PRINT '用户mr锁定的时间为:'+ @now_time
/*等待10秒*/
WAITFOR DELAY '00:00:10'
SELECT @now_time = CONVERT(VARCHAR,GETDATE(),8)
/*显示解锁时间*/
PRINT '用户mr解锁的时间为:'+ @now_time
/*提交事务，解除锁定*/
COMMIT TRAN

/*开始事务*/
BEGIN TRAN 
/*定义变量*/
DECLARE @now_time VARCHAR(8)
SELECT @now_time = CONVERT(VARCHAR,GETDATE(),8)
/*显示事务开始时间*/
PRINT '用户mrsoft开始事务的时间:'+ @now_time
SELECT * FROM tb_mrBook15
WHERE 图书编号=2
SELECT @now_time = CONVERT(VARCHAR,GETDATE(),8)
/*显示SELECT语句执行时间*/
PRINT '用户mrsoft执行SELECT语句的时间:'+ @now_time
UPDATE tb_mrBook15 SET 图书名称='SQL范例宝典'
WHERE 图书编号=2
SELECT @now_time = CONVERT(VARCHAR,GETDATE(),8)
/*显示UPDATE语句执行时间*/
PRINT '用户mrsoft执行UPDATE语句的时间:'+ @now_time
/*回滚事务*/
ROLLBACK




/*设置事务READ UNCOMMITTED（未提交读）
隔离级别*/
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
/*开始事务*/
BEGIN TRAN mrdata
/*更新操作*/
UPDATE tb_Register15 SET 家庭住址='哈尔滨市'
WHERE 会员编号=1
PRINT '事务结前表中的数据'
SELECT * FROM tb_Register15
/*等待10秒*/
WAITFOR DELAY '00:00:10'
/*回滚结束事务*/
ROLLBACK TRANSACTION mrdata
PRINT '事务结束后表中的数据'
SELECT * FROM tb_Register15

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
PRINT '读取了“脏数据",即用户mr修改中间的数据'
SELECT * FROM tb_Register15
/*查询的结果不为空*/
IF @@ROWCOUNT>0
BEGIN 
/*等待10秒，用户mr的操作已完成*/
  WAITFOR DELAY '00:00:10'
  PRINT '不重复读，即两次SELECT语句结果不同'
  SELECT * FROM tb_Register15
END



Set xact_Abort on
/*显示启动分布式事务*/
Begin DISTRIBUTED TRANSACTION
Update Employees set Firstname='Nancy' 
where Lastname='Davolio'
Update [MRLFL].[Northwind].[dbo].[Employees] 
set FirstName='Nancy'
where LastName='Davolio'
/*结束分布式事务*/
COMMIT TRANSACTION


