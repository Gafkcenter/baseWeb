SELECT AVG(salary) AS 平均值
FROM tb_treatment08


SELECT AVG(num) 
FROM tb_EA08


SELECT AVG(salary) AS 平均工资
FROM tb_treatment08
WHERE (salary > 2500)



SELECT COUNT(*) AS 个数
FROM tb_treatment08
WHERE (salary > 2500)



SELECT COUNT(duty) AS 个数
FROM tb_treatment08


SELECT AVG(salary) AS 去掉最大值与最小值的平均值
FROM tb_treatment08
WHERE salary NOT IN
          ((SELECT MIN(salary) AS 最小值
          FROM tb_treatment08)
      UNION
      (SELECT MAX(salary) AS 最大值
      FROM tb_treatment08))

	  
	  
	  SELECT SUM(salary) AS 所有薪水加和
FROM tb_treatment08


SELECT SUM(salary + bonus) AS 实发工资的加和
FROM tb_treatment08


SELECT *
FROM tb_treatment08
WHERE (birthday BETWEEN '1980-01-01' AND '1990-01-01') AND (salary >
          (SELECT AVG(salary)
         FROM tb_treatment08))

		 
		 
		 select NVL(duty,'暂无职位'),
count(NVL(duty,'暂无职位')) 职位个数 
from tb_treatment08 
group by NVL(duty,'暂无职位');


SELECT dept, AVG(salary) AS 工资平均值, SUM(bonus) AS 奖金总和, MAX(salary) 
      AS 最高工资, MIN(salary) AS 最低工资, COUNT(*) AS 人数
FROM tb_treatment08
GROUP BY dept


SELECT dept, sex, AVG(salary) AS 工资平均值, SUM(bonus) AS 奖金总和, MAX(salary) 
      AS 最高工资, MIN(salary) AS 最低工资, COUNT(*) AS 人数
FROM tb_treatment08
GROUP BY dept, sex



SELECT name + ' 是 ' + sex + '性 ' AS 基本资料, 
      '是 ' + dept + '的' + duty AS expression2
FROM tb_treatment08
GROUP BY 基本资料, expression2



SELECT dept, name, SUM(salary) AS 工资总和
FROM tb_treatment08
GROUP BY ROLLUP (dept, name);

SELECT dept, duty, SUM(salary) AS 工资总和
FROM tb_treatment08
GROUP BY dept, duty WITH ROLLUP



SELECT dept, name, SUM(salary) AS 工资总和
FROM tb_treatment08
GROUP BY CUBE (dept, name);

SELECT dept, duty, SUM(salary) AS 工资总和
FROM tb_treatment08
GROUP BY dept, duty WITH cube



SELECT duty, COUNT(*) AS ?λ??
FROM tb_treatment08
GROUP BY duty



SELECT dept, salary, COUNT(dept) AS 人数
FROM tb_treatment08
WHERE (birthday BETWEEN '1980-01-01' AND '1990-01-01')
GROUP BY dept, salary
HAVING (salary >
          (SELECT AVG(salary)
         FROM tb_treatment08))
ORDER BY salary DESC



SELECT duty, dept
FROM tb_treatment08
GROUP BY dept, duty
HAVING (duty NOT IN ('经理'))



select * from tb_treatment08 
order by dept
compute sum(salary),min(salary),avg(salary)



select * from tb_treatment08 
order by dept
compute sum(salary),min(salary),avg(salary) by dept


SELECT dept, COUNT(dept) AS 部门个数
FROM tb_treatment08
GROUP BY dept
ORDER BY 部门个数 DESC



SELECT *
FROM tb_treatment08
WHERE (salary > ALL
          (SELECT AVG(salary)
         FROM tb_treatment08
         GROUP BY dept))

		 
		 
		 SELECT AVG(salary) AS 平均工资
FROM tb_treatment08
GROUP BY dept
