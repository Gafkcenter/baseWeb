use db_mrsql
select * from tb_str05 where Ооич like '%%' 
select * from tb_str05 where Ооич like '\%%' escape '\'



use db_mrsql
select * from tb_student06
select 编号,姓名,性别,年龄 from(select row_number() over (order by 编号) 
n,编号,姓名,性别,年龄 from tb_student06 )x
where n between 3 and 6






use db_mrsql
select * from tb_student06
select 编号,姓名,性别,年龄 from(select row_number() over (order by 编号) 
n,编号,姓名,性别,年龄 from tb_student06 )x
where n between 3 and 6




use db_mrsql
select * from tb_bookInfo06
select * from tb_bookInfo06 where 出版社 is null


use db_mrsql
select * from tb_bookInfo06
select * from tb_bookInfo06 where зїеп is not null


use db_mrsql
select * from tb_bookInfo06
select 编号,书名,作者,isnull(出版社,'无') as 出版社,价格 from tb_bookInfo06


use db_mrsql
select * from tb_bookInfo06
select 编号,书名,作者,nullif(出版社,'电月') as 出版社,价格 
 from tb_bookInfo06

 
 use db_mrsql
select * from tb_employee06
select * into tb_programmer from tb_employee06 where 职务='程序员'
select * from tb_programmer


use db_mrsql
select * from tb_employee06
select * into #DONET from tb_employee06 where 部门='.NET'
select * from #DONET


use db_mrsql
select * from tb_studentScore05
select * from (select top 3 * from tb_studentScore05) aa 
where not exists (select * from (select  top 2 * from tb_studentScore05) 
bb where aa.id=bb.id )


use db_mrsql
select * from tb_student06

create procedure PRO_student
@n int
as 
select * from (select top (@n) * from tb_student06) aa 
where not exists (select * from (select  top (@n-1) * from tb_student06)
 bb where aa.编号=bb.编号 )

exec PRO_student 2


use db_mrsql
select * from tb_chineseScore06
select a.学号,b.考试号,a.成绩 from 
(select 学号,max(成绩) as 成绩 from tb_chineseScore06 group by 学号)as a
inner join tb_chineseScore06 as b on 
a.学号=b.学号 and a.成绩=b.成绩 order by a.学号


use db_mrsql
select * from tb_employeePay08
select 工号,姓名,职务,部门,(select count(工号) from tb_employeePay08 a where 
a.部门=b.部门 )as 部门人数 from tb_employeePay08 b where 职务='经理'


use db_mrsql
select * from tb_employeePay08
select * from tb_employeePay08 a where 基本工资=
(select min(基本工资)from tb_employeePay08 b where a.部门=b.部门 and 职务!='经理' )



