USE db_mrsql
GO
CREATE PROCEDURE CRE_PRO AS
Select * from tb_tab11 where лн▒­='─л'
GO



USE db_mrsql
GO
CREATE PROCEDURE CRE_Group;1 AS
Select * from tb_tab11
GO
CREATE PROCEDURE CRE_Group;2 AS
Select * from tb_tab11 where 性别='男'
GO
CREATE PROCEDURE CRE_Group;3 AS
Select * from tb_tab11 where 性别='女'



--创建存储过程
USE db_mrsql
GO
CREATE PROCEDURE CRE_CX
AS
if EXISTS(Select * from tb_tab11 where 年龄='22')
  Print 'tb_tab11数据表中有信息。'    --表示查询结果至少有一条记录
else 
  Print 'tb_tab11数据表中无信息。'    --没有查询到任何记录
GO
--执行存储过程
EXEC CRE_CX



--创建存储过程
CREATE PROCEDURE CRE_PRI
@char char(10)
AS
if EXISTS(Select * from tb_tab11 where (姓名=@char)and(年龄<18))
  Print Rtrim(@char)+'是未成年人员'    --表示查询结果至少有一条记录
else 
  Print Rtrim(@char)+'不是未成年人员'    --没有查询到任何记录
GO
--执行存储过程
EXEC CRE_PRI'小张'



--创建存储过程
USE db_mrsql
GO
CREATE PROCEDURE CRE_RAIS
@ErrorMessage varchar(100)
AS
Set @ErrorMessage =@ErrorMessage+ '单号不存在'
Raiserror (@ErrorMessage,16,1)
GO
--执行存储过程
EXEC CRE_RAIS '1001'



--创建存储过程
USE db_mrsql
GO
CREATE PROCEDURE CRE_Raiser 
@ID int,
@姓名 int
AS
if EXISTS(SELECT * FROM tb_tab11 WHERE 编号 = @ID)
begin
  UPDATE tb_tab11
  SET 姓名 = 姓名 + @姓名
  WHERE 编号 = @ID
end
else
begin
  RAISERROR ('存储过程提示: 数据库更新数据失败, 请确认[编号]为%d的信息是否存在',
 16, 1, @ID)
  Return
end
GO
--执行存储过程
EXEC CRE_Raiser 5,30



--创建带返回值的存储过程
USE db_mrsql
GO
CREATE PROCEDURE CRE_CONV
@SEX Varchar(2)='男',
@IntOut Int OUTPUT
AS
Select * 
from tb_tables11 
where 性别='男'
Set @IntOut=@@Error
GO
DECLARE @IntOut_Return int
EXEC CRE_CONV @SEX='女',@IntOut=@IntOut_Return OutPut
PRINT '返回结果为:'+convert(varchar(6),@IntOut_Return)+'.'



--创建存储过程
USE db_mrsql
GO
CREATE PROCEDURE CRE_RET
@ID int=0,
@Int int OutPut
AS
if @ID=0
begin
  Print '错误：必须入@ID参数'
  Return 1
end
else
begin
  if (select count(*) from tb_table11 where UserID=@id)=0
  begin
    Print '错误：@ID参数无效'  
    Return 2
  end
end
select * from tb_table11 where UserID=@id
if @@ERROR=0
  Return 0
else
  Return 3
GO
--执行存储过程
Declare @cost int,@Out int
EXEC @cost=CRE_RET @id=3,@int=@Out OutPut    --在tb_table11表中只有两条记录
if @cost=0
  Print '查询成功'
if @cost=1
  Print '参数不能为0'
if @cost=2
  Print '参数不能超出范围'
if @cost=3
  Print '查询时发生错误'

  
  
  Create Procedure CTE_SW
as
declare @UserID int
set nocount on
begin tran AddUser
insert into tb_table11 (UserName,PassWord,Tel) values ('mr','123','123455')
if @@Error <> 0 or @@rowcount = 0 goto ErrMsg
set @UserID = @@identity
set nocount off
commit tran AddUser
return 1 --添加成功
ErrMsg:
   set nocount off
   rollback tran AddUser
   return -1   --添加失败并回滚
GO




--创建存储过程
USE db_mrsql
GO
CREATE PROCEDURE CRE_Return 
@ID int,
@Pice int
AS
SELECT * FROM tb_table11 WHERE UserID = @ID
Return @@Error
GO
--执行存储过程
DECLARE @Int int
EXEC @Int=CRE_Return 1,30    --将返回值赋给@Int变量
Select @Int as '返回值'    --显示返回信息



USE db_mrsql
EXEC CRE_PRO



use master
exec sp_procoption 'loving','startup','true'



--创建带返回值的存储过程
CREATE PROCEDURE CRE_OUP
  @ave int OUTPUT    --设置带返回值的参数
AS
select @ave =avg(年龄) from tb_tab11
GO
--执行存储过程
DECLARE @average int    --自定义变量
EXEC CRE_OUP @average output    --调用存储过程
if @average>=25    --利用存储过程的返回值进行判断
  PRINT '人员的平均年龄为'+cast(@average as char(2))+'，属于年龄偏高'
if @average>=18
  PRINT '人员的平均年龄为'+cast(@average as char(2))+'，属于年龄居中'
if @average<18
  PRINT '人员的平均年龄为'+cast(@average as char(2))+'，属于年龄偏低'

  
  
  USE db_mrsql
GO
EXEC sp_helptext CRE_PRO
EXEC sp_depends CRE_PRO
EXEC sp_help CRE_PRO
GO



ALTER PROCEDURE CRE_PRO
AS
SELECT 姓名,性别,年龄
FROM tb_tab11
WHERE 性别='女'
GO
EXEC CRE_PRO
GO



USE db_mrsql
GO
CREATE PROCEDURE CRE_anew 
WITH RECOMPILE
AS
Select * from tb_tab11
GO



create or replace procedure proc
as
  age number;
begin
  select count(age) into age from tb_ta15;
end;
/



CREATE PROCEDURE proc (OUT param1 INT)
BEGIN
  SELECT COUNT(*) INTO param1 FROM tb_t15;
END;
//

