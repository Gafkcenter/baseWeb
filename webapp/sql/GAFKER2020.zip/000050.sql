use db_mrsql   --使用db_mrsql数据库       
insert into tb_home04 -–向房屋信息表中插入一条记录
(住房编号,住房名称,住房类别,住户姓名,备注信息)
values(1001,'XX名称','一室一厅','王雪健','无')
GO
select * from tb_home04  --查看房屋信息表插入后的数据信息



use db_mrsql --使用db_mrsql数据库
GO
select * from tb_huiyuan04 --查询数据表中的信息
--向数据表中插入NULL值
insert into tb_huiyuan04 values('H-1004','王雨婷',NULL,NULL)
--查看插入后的数据表中的信息
select * from tb_huiyuan04




use db_mrsql--使用db_mrsql数据库
select * from tb_yuangong05
use db_mrsql--使用db_mrsql数据库
--向数据表中插入一条数据数据，系统将会报错
insert into tb_yuangong05
values(1005,'孙建国','230108XXXXXXXXXXXX','无')



use db_mrsql --使用db_mrsql数据库
insert into tb_shopping04  --向商品信息表“tb_shopping04”中插入一条数据
(商品编号,商品名称,商品数量,上市日期)
values(1023,'洗衣粉','200','2008-3-5')
GO
use db_mrsql --使用db_mrsql数据库
select * from  tb_shopping04  --查看插入数据后数据表中的信息



use db_mrsql  --使用db_mrsql数据库        
insert into car04 –-向车辆信息表中插入一条数据
(车辆编号,车辆名称)
values(1001,'车辆1') 


use db_mrsql--使用db_mrsql数据库
GO
--查询数据表中的信息内容
select * from tb_person04
--向数据表中插入一条数据
insert into 
tb_person04(人员编号,人员名称,人员备注) 
values(1004,'王强','他是一名勤奋的人！')
--查询插入后的数据表中的信息情况
select * from tb_person04


use db_mrsql--使用db_mrsql数据库
GO
--判断“tb_stu04”信息表是否存在，如果存在将该信息表删除
      if exists(select * from INFORMATION_SCHEMA.TABLES 
        where table_name = 'tb_stu04')
        drop table tb_stu04  --删除该信息表
GO
--创建tb_stu04数据信息表
create table tb_stu04
(
 编号 char(11) NOT NULL,
 姓名 varchar(40) NOT NULL,
 出生年月日 datetime ,--将该字段设置为日期时间类型
 备注 text
)
GO
--向该表中插入数据
insert into tb_stu04 values('M-1001','张晓波',getdate(),'无')
--查看插入数据后的信息
select * from tb_stu04


use db_mrsql--使用db_mrsql数据库
GO
/*基于员工信息表“tb_yuangong05”
创建视图“view_yuangong”*/
create view view_yuangong
as
select * from tb_yuangong05
--查看创建后的视图信息
select * from view_yuangong
insert into view_yuangong 
values(1008,'孙涛','230108888888XXXXXX','暂无')
GO
select * from tb_yuangong05





use db_mrsql --使用db_mrsql数据库
GO
--查询插入前的图书信息表“tb_booksell05”中的数据
select * from tb_booksell05
insert into 
tb_booksell05(bookname,id,bookprice,booksum)
values('XX小说',10008,20,10)
GO
--查询插入后的图书信息表中的数据
select * from tb_booksell05



use db_mrsql--使用db_mrsql数据库
--创建工人信息"tb_worker05"表
create table tb_worker05
(
  工人编号 int,
  工人姓名 varchar(20),
  工人性别 char(2),
  工人备注 varchar(50)
)
insert into tb_worker05
values('m101','小强','女','暂无')



use db_mrsql--使用db_mrsql数据库
insert into tb_pupil05
values(1001,'王月','女')



use db_mrsql –使用db_mrsql数据库
--向学生信息表“tb_stu04”中,一次插入3条数据
insert into tb_stu04
values
(1001,’jim’,’男’),
(1002,’tom’,’女’),
(1003,’marry’,’女’);



use db_mrsql--使用db_mrsql数据库
GO
--查看插入数据后的信息
select * from tb_stu04
/*使用SELECT语句批量插入数据,
把学生基本信息表“tb_stu04”中的数据批量追加*/
insert into tb_stu04 select * from tb_stu04
--查询批量插入数据后数据表中的信息
select * from tb_stu04




use db_mrsql--使用db_mrsql数据库
GO
/*查询数据表“tb_stu05”中的数据信息，把
查找搭配的“学生编号”、“学生姓名”、
“学生总成绩”字段信息插入到新创建的数据
表“tb_newstu05”中*/
select 学生编号,学生姓名,学生总成绩
into tb_newstu05
from tb_stu05
GO
--查看“tb_stu05”数据表中的数据信息
select * from tb_stu05
--查看新创建的数据表“tb_newstu05”中的数据信息
select * from tb_newstu05




use db_mrsql --使用db_mrsql数据库
GO
EXEC master..xp_cmdshell
'bcp db_mrsql.dbo.tb_car04 out F:\db_student.txt -c -q -S "MRGWH" -U "sa" -P""'



SELECT * into tb_mrgwh22
FROM OpenDataSource( 'Microsoft.Jet.OLEDB.4.0',
  'Data Source="e:\mrgwh.xls";
User ID=Admin;Password=;
Extended properties=Excel 5.0')...Sheet1$
/*动态文件名
declare @fn varchar(20),@s varchar(1000)
set @fn = 'e:\mrgwh.xls'
set @s = '"Microsoft.Jet.OLEDB.4.0","Data Source="'+@fn+'";User ID=Admin;Password=;
Extended properties=Excel 5.0"'
set @s = 'SELECT * FROM OpenDataSource ('+@s+'))...Sheet1$
exec (@s)'
*/



use db_mrsql --使用db_mrsql数据库
GO
EXEC master..xp_cmdshell 'bcp db_mrsql.dbo.tb_yuangong05 out E:\db_yuangong.xls -c -q -S "MRGWH" 
-U"sa" -P""'




insert into tb_mrfang22
 select 员工姓名,员工编号,所在部门 from openrowset
('Microsoft.Jet.OLEDB.4.0',
'E:\mrfdw.mdb';'admin';'',tb_mrMembers22)



insert into openrowset
('Microsoft.Jet.OLEDB.4.0',
'E:\mrfdw.mdb';'admin';'',tb_mrfdw22)
select * from db_sql..tb_mrgwh22


