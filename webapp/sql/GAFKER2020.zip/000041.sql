use db_mrsql
exec sp_renamedb 'mr', 'mrsoft'


use db_mrsql
drop database teacher 


use db_mrsql
drop database hello,every,person


use db_mrsql  --使用db_mrsql数据库
create  table teacher --创建“teacher”信息表
(
 教师编号 int, 
 教师姓名  varchar(10), 
 教师年龄  int,
 所教课程  varchar(30) 
)  


use db_mrsql
create table shopping
(
商品编号 int primary key, --使用primary key将“商品编号”字段设置为主键列
商品类别 varchar(10),
商品数量 int,
商品备注 text 
)  


use db_mrsql   --使用db_mrsql数据库  
create table pupil   --创建tb_pupil04数据表 
(
 学生学号  varchar(8),
 学生姓名  varchar(10) unique,-- 定义了具有唯一值（unique）的“学生姓名”列
 -- 创建一个检验约束(check)检验“学生年龄”列的值是否在8到15之间
学生年龄  int check(学生年龄>=8 and 学生年龄<=15), 
 学生性别  int,
 备注 text 
)


use db_mrsql  --使用db_mrsql数据库    
create  table tb_student04   --创建学生信息表tb_student04
(
 学号  varchar(8) not null,--指定学号列不能为空
 姓名  varchar(10) unique, -- 定义了具有唯一值（unique）的“姓名”列
 -- 创建一个检验约束(check)检验“年龄”列的值是否在10到20之间
 年龄  int check(年龄>=10 and 年龄<=20),
 性别  char(2) not null--指定性别列不能为空
)


use db_mrsql                --使用db_mrsql数据库 
create table tb_member04  --创建会员信息表tb_member04
(
 会员编号 int,
 会员名称 varchar(20),
 /*为“会员性别”列指定了默认值,将默认值设置为“男”*/
 会员性别 char(2) default '男',
 会员年龄 int,
 备注 text
)


use db_mrsql--使用db_mrsql数据库
create table tb_employee04----创建员工信息表tb_employee04
(
 员工编号 int,
 员工名称 varchar(20),
 基本工资 float,
 浮动奖金 float,
 --“所得奖金”列是由“基本工资”和“浮动奖金”两个列的和计算得到的
 所得金额 as (基本工资+浮动奖金),  
 备注 text
)


use db_mrsql--使用db_mrsql数据库
create table tb_employee04----创建员工信息表tb_employee04
(
 员工编号 int,
 员工名称 varchar(20),
 基本工资 float,
 浮动奖金 float,
 --“所得奖金”列是由“基本工资”和“浮动奖金”两个列的和计算得到的
 所得金额 as (基本工资+浮动奖金),  
 备注 text
)


use db_mrsql--使用db_mrsql 数据库
create table #materia  --创建临时表“#materia”
(
 药品编号 int,
 药品名称  varchar(20),
 药品数量  int,
 备注 text
)


