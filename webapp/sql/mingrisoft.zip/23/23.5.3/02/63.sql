SELECT SOUNDEX('Blotchet-Halls') as 'Blotchet-Halls',
  SOUNDEX('Greene') as 'Greene',
  DIFFERENCE('Blotchet-Halls', 'Greene')as '�������'
