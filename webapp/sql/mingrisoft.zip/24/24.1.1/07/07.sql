alter session set nls_date_format = 'mm-dd-yyyy' ;
select current_date from dual;
