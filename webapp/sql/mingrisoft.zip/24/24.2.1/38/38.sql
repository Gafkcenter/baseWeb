select add_months(sysdate,12) "Next Year",
add_months(sysdate,-12) "Last Year" from dual;
